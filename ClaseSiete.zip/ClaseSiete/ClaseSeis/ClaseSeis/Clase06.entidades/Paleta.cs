﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase06.entidades
{
    public class Paleta
    {
        private Tempera[] _colores;
        private int _cantMaximaColores;


        private Paleta() :this(5)
        {
        }

        private Paleta(int cant) 
        {
            this._cantMaximaColores = cant;                 
            this._colores = new Tempera [this._cantMaximaColores];
        }

        public static implicit operator Paleta (int c)
        {
            return new Paleta(c);
        }
        public static implicit operator string(Paleta p)
        {
            return p.ToString();
        }

        private string Mostrar()
        {
            string ret = ""; 
            foreach(Tempera i in this._colores)
            {
                ret += Tempera.Mostrar(i);
            }
           
            return "Cantidad: " + this._cantMaximaColores + "\nColores:\n"+ ret; 
        }

        public static string Mostrar(Paleta p)
        {
            return p.Mostrar(); 
        }


    }
}
