﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase06.entidades
{
    public class Tempera
    {
        private ConsoleColor _color;
        private string _marca;
        private int _cantidad;

        public Tempera(ConsoleColor color, string marca, int cantidad)
        {
            this._color = color;
            this._cantidad = cantidad;
            this._marca = marca;
        }

        private string Mostrar()
        {
            return "Color: " + this._color + "\n Cantidad: " + this._cantidad + "\n Marca: " + this._marca;
        }

        public static string Mostrar(Tempera obj)
        {
            return obj.Mostrar();
        }


        public static bool operator ==(Tempera obj1, Tempera obj2)
        {
            return obj1._marca == obj2._marca && obj1._color == obj2._color;
        }
        public static bool operator !=(Tempera obj, Tempera obj2)
        {
            return (!(obj == obj2));
        }


        public static Tempera operator +(Tempera obj, double a)
        {
            if (a > 0 && (obj._cantidad + a) <= 100)
            {
                obj._cantidad += (int) a;
            }

            return obj;
        }


        public static implicit operator int (Tempera temp)
        {
            return temp._cantidad;
        }


        

    }
}
