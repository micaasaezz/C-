﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase06.entidades
{
    public class Paleta
    {
        private Tempera[] _colores;
        private int _cantMaximaColores;


        private Paleta() :this(5)
        {
        }

        private Paleta(int cant) 
        {
            this._cantMaximaColores = cant;                 
            this._colores = new Tempera [this._cantMaximaColores];
        }

        public static implicit operator Paleta (int c)
        {
            return new Paleta(c);
        }
        public static implicit operator string(Paleta p)
        {
            return p.ToString();
        }

        private string Mostrar()
        {
            string ret = "";
            for (int i = 0; i < this._cantMaximaColores; i++)
            {
                if (this._colores.GetValue(i) != null)
                {
                    ret +=Tempera.Mostrar(this._colores[i]);
                }
            }            
           
            return "Cantidad: " + this._cantMaximaColores + "\n Colores:\n"+ ret; 
        }

        public static string Mostrar(Paleta p)
        {
            return p.Mostrar(); 
        }

        public static bool operator ==(Paleta p, Tempera t)
        {
            bool ret = false;
            for (int i = 0; i < p._cantMaximaColores; i++)
            {
                if (p._colores.GetValue(i) != null)
                {
                    if (p._colores[i] == t)
                    {
                        ret = true;
                        break;
                    }
                }
            }
            return ret;            
            
        }
        public static bool operator !=(Paleta p, Tempera t)
        {
            return !(p == t);
        }


        private int ObtenerIndice()
        {
            int ret = -1;
            for (int i = 0; i < this._cantMaximaColores; i++)
            {
                if (this._colores.GetValue(i) == null)
                {
                    ret = i;
                    break;
                }
            }
            return ret;
        }


        
        //+(paleta, tempera):paleta -> si la tempera NO esta en la paleta
        public static Paleta operator + (Paleta paleta, Tempera temp)
        {
            if (paleta != temp)//la paleta no contiene ese color
            {
                if (paleta.ObtenerIndice() != -1)
                {
                    paleta._colores[paleta.ObtenerIndice()] = temp;
                }

            }
            else  //si el color ya esta en la paleta
            {
                for(int i=0; i< paleta._cantMaximaColores; i++)
                {
                    if(paleta._colores[i] == temp)
                    {
                        paleta._colores[i] += temp;
                        break;
                    }
                }
                                
            }
            return paleta;
        }



        //-(paleta, tempera):paleta  -> si la tempera esta en la paleta

        public static Paleta operator -(Paleta p, Tempera t)
        {
            if(p == t)
            {
                for (int i = 0; i < p._cantMaximaColores; i++)
                {
                    if (p._colores[i] == t)
                    {
                        p._colores[i] = null;
                        break;
                    }
                }
                
            }
            return p;
        }

        //+(paleta, paleta):paleta
        //public static Paleta operator +(Paleta p, Paleta p1)
        //{
        //    Paleta paletaNueva;



        //    return paletaNueva;
        //}

    }
}
