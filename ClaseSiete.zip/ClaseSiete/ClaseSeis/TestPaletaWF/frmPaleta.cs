﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Clase06.entidades;

namespace TestPaletaWF
{
    public partial class frmPaleta : Form
    {

        private Paleta _paleta;
        


        public frmPaleta()
        {
            InitializeComponent();
            this._paleta = 5;
        }

        private void button3_Click(object sender, EventArgs e) //+
        {
            //Tempera tempera = new Tempera(ConsoleColor.Cyan, "filgo", 9);
            //this._paleta += tempera;
            //lstColores.Items.Clear();
            //lstColores.Items.Add(Paleta.Mostrar(this._paleta));
            
            frmTempera frmTempera = new frmTempera();
            frmTempera.ShowDialog();

            if(

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e) // -
        {
            Tempera tempera = new Tempera(ConsoleColor.Cyan, "filgo", 9);
            this._paleta -= tempera;
            lstColores.Items.Clear();
            lstColores.Items.Add(Paleta.Mostrar(this._paleta));
        }

        


        

        
    }
}
