﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clase06.entidades;


namespace Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            //Vectores
            // tipo[] nombre;
            int[] vec;

            vec = new int[3];
            vec[0] = 32;
            vec[1] = 16;

            //foreach ( tipo i in collection )
            foreach (int i in vec)
            {
                Console.WriteLine(i);
            }

            //Matrices
            // tipo [ , ] nombre = new tipo[2,3];


            Tempera temp = new Tempera(ConsoleColor.Cyan, "filgo", 61);
            Tempera temp2 = new Tempera(ConsoleColor.Cyan, "filgo", 13);

            if (temp == temp2)
            {
                Console.WriteLine("Tempera uno y dos son iguales");
            }
            else
            {
                Console.WriteLine("Tempera uno y dos no son iguales"); 
            }

            
            temp += 40;

            Console.WriteLine("\n" + Tempera.Mostrar(temp2));
            Console.WriteLine("\n" + Tempera.Mostrar(temp));

            Paleta p = 8;
            Console.WriteLine(Paleta.Mostrar(p));



            Console.Read();
        }
    }
}
