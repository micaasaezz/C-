﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public static class Verificadora
    {
        public static bool VerificarNumero(Numero n, ETipoNumero tipo)
        {
            bool ret = false;

            switch (tipo)
            {
                case ETipoNumero.Par:
                    if (n.Valor % 2 == 0)
                    {
                        ret = true;
                    }
                    break;
                case ETipoNumero.Impar:
                    if (n.Valor % 2 != 0)
                    {
                        ret = true;
                    }
                    break;
                case ETipoNumero.Positivo:
                    if (n.Valor > 0)
                    {
                        ret = true; 
                    }
                    break;
                case ETipoNumero.Negativo:
                    if (n.Valor < 0)
                    {
                        ret = true;
                    }
                    break;
                case ETipoNumero.Cero:
                    if (n.Valor == 0)
                    {
                        ret = true;
                    }
                    break;
                
            }
            return ret;
        }


    }
}
