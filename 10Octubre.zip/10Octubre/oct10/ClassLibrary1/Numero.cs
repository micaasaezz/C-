﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Numero
    {
        protected int _numero;

        public int Valor 
        {
            get
            {
                return this._numero;
            }
        }

        public Numero(int numero)
        {
            try
            {
                this._numero = numero; 
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
            }
            
        }


        public static int operator +(Numero n1, Numero n2)
        {
            return n1.Valor + n2.Valor;
        }
        public static int operator -(Numero n1, Numero n2)
        {
            return n1.Valor - n2.Valor;
        }
        public static int operator *(Numero n1, Numero n2)
        {
            return n1.Valor * n2.Valor;
        }
        public static double operator /(Numero n1, Numero n2)
        {
            double ret = 0;
            try
            {
                ret = n1.Valor / n2.Valor;
            }
            catch (DivideByZeroException e)
            {
                Console.WriteLine(e.Message);
            }
            return ret; 
        }
        

    }
}
