﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class ColectoraDeNumeros
    {
        private List<Numero> _numeros;

        private ColectoraDeNumeros()
        {
            this._numeros = new List<Numero>();
        }

        public ColectoraDeNumeros(ETipoNumero n) : this()
        {
            this.Numeros = n;
        }

        public ETipoNumero Numeros
        {
            get;
            set;
        }

        public int SumaPrimerNumero 
        {
            get
            {
                return this.Calcular(EResultado.Suma);
            }
        }
        public int RestaPrimerNumero
        {
            get
            {
                return this.Calcular(EResultado.Resta);
            }
        }
        public int MultPrimerNumero
        {
            get
            {
                return this.Calcular(EResultado.Multiplicacion);
            }
        }
        public int DivPrimerNumero
        {
            get
            {
                return this.Calcular(EResultado.Division);


            }
        }
        private int Calcular(EResultado operador)
        {
            int retorno = this._numeros[0].Valor;
            for (int i = 1; i < this._numeros.Count(); i++)
            {
                switch (operador)
                {
                    case EResultado.Suma:
                        retorno += this._numeros[i].Valor;
                        break;
                    case EResultado.Resta:
                        retorno -= this._numeros[i].Valor;
                        break;
                    case EResultado.Division:
                        retorno /= this._numeros[i].Valor;
                        break;
                    case EResultado.Multiplicacion:
                        retorno *= this._numeros[i].Valor;
                        break;
                }
               
            }
            return retorno;
        }

        public static ColectoraDeNumeros operator +(ColectoraDeNumeros c, Numero n)
        {
            if (Verificadora.VerificarNumero(n, c.Numeros))
            {
                c._numeros.Add(n);
            }
            else
            {
                Console.WriteLine("No se puede agregar distinto tipo!");
            }
            
            return c;
        }
        public static ColectoraDeNumeros operator -(ColectoraDeNumeros c, Numero n)
        {
            c._numeros.Remove(n);
            return c;
        }


        public override string ToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.Append("Cantidad de numeros: ");
            ret.AppendLine(this._numeros.Count.ToString());
            ret.AppendLine("Numeros: ");
            foreach(Numero i in this._numeros)
            {
                ret.AppendLine(i.Valor.ToString());
            }

            return ret.ToString();
        }


    }
}
