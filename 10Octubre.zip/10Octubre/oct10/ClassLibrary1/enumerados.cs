﻿public enum ETipoNumero
{
    Par, Impar, Positivo, Negativo, Cero
}

public enum EResultado
{
    Suma, Resta, Division, Multiplicacion
}
