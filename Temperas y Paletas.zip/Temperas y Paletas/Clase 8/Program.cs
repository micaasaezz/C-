﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clase8;
namespace Clase_8
{
    class Program
    {
        static void Main(string[] args)
        {
            //Tempera tempera = new Tempera(ConsoleColor.Blue, "filgo", 20);
            Paleta paleta = 5;
            paleta[0] = new Tempera(ConsoleColor.Blue, "filgo", 20);
            paleta[1] = new Tempera(ConsoleColor.Blue, "filgo", 20);
            

            Console.WriteLine(Tempera.Mostrar(paleta[0]));
            Console.Read();
            

        }
    }
}
