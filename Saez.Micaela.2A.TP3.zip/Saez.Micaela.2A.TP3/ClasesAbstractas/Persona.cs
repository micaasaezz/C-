﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;

namespace EntidadesAbstractas
{
    public abstract class Persona
    {
        private string _apellido;
        private int _dni;
        private ENacionalidad _nacionalidad;
        private string _nombre;

        public string Apellido
        {
            get { return this._apellido; }
            set { this._apellido = this.ValidarNombreApellido(value); }
        }
        public int DNI
        {
            get { return this._dni; }
            set { this._dni = this.ValidarDni(this._nacionalidad, value); }
        }
        public ENacionalidad Nacionalidad
        {
            get { return this._nacionalidad; }
            set { this._nacionalidad = value; }
        }
        public string Nombre
        {
            get { return this._nombre; }
            set { this._nombre = this.ValidarNombreApellido(value); }
        }
        public string StringToDNI
        {
            set { this._dni = this.ValidarDni(this.Nacionalidad, value); }
        }


        public Persona()
        {

        }
        public Persona(string nombre, string apellido, ENacionalidad nacionalidad)
        {
            this._nombre = nombre;
            this._apellido = apellido;
            this._nacionalidad = nacionalidad;
        }
        public Persona(string nombre, string apellido, int dni, ENacionalidad nacionalidad)
            :this(nombre, apellido, nacionalidad)
        {
            this._dni = dni;
        }
        public Persona(string nombre, string apellido, string dni, ENacionalidad nacionalidad)
            :this(nombre, apellido, nacionalidad)
        {
            this.StringToDNI = dni;
        }

        public override string ToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.AppendLine("NOMBRE COMPLETO: " + this.Apellido + " " + this.Nombre);
            ret.Append("NACIONALIDAD: " + this.Nacionalidad);
            return ret.ToString();
        }

        private int ValidarDni(ENacionalidad nacionalidad, int dato)
        {
            if (nacionalidad == ENacionalidad.Argentino)
            {
                if (dato < 1 || dato > 89999999)
                {
                   throw new DniInvalidoException();
                }               
            }
            else if(nacionalidad == ENacionalidad.Extranjero)
            {
                if (dato < 90000000)
                {
                    throw new NacionalidadInvalidaException("La nacionalidad no se condice con el numero de DNI");
                }
            }

            return dato;
        }
        private int ValidarDni(ENacionalidad nacionalidad, string dato)
        {
            foreach (char item in dato)
            {
                if (!(char.IsDigit(item)))
                {
                    throw new DniInvalidoException("Dni invalido");
                }
            }

            return this.ValidarDni(nacionalidad, int.Parse(dato));
        }
        private string ValidarNombreApellido(string dato)
        {
            int i = 0;
            bool nombreCorrecto = true;
            while (dato[i] != '\0')
            {
                if (!((dato[i] > 'a' && dato[i]<'z') || (dato[i]>'A' && dato[i] <'Z')))
                {
                    nombreCorrecto = false;
                }
                i++;
            }
            if(nombreCorrecto == true)
            {
                this._nombre = dato;
            }

            return dato;
        }


        public enum ENacionalidad
        {
            Argentino, Extranjero
        }

    }
}
