﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Archivos
{
    public class Texto : IArchivo<string>
    {
        public bool Guardar(string archivo, string datos)
        {
            StreamWriter escritor = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + archivo);
            escritor.WriteLine(datos);
            escritor.Close();
            return true;
        }
        public bool Leer(string archivo, out string datos)
        {
            StreamReader lector = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + archivo);
            datos = lector.ReadToEnd();
            lector.Close();
            return true;
        }

    }
}
