﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Platano : Fruta
    {
        public string paisOrigen;

        
        public override bool TieneCarozo
        {
            get { return false; }
        }

        public string Tipo
        {
            get { return "Platano"; }
        }


        public Platano(float peso, ConsoleColor color, string pais)
            :base(peso, color)
        {
            this.paisOrigen = pais; 
        }

        protected override string FrutaToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.AppendLine(base.FrutaToString());
            ret.AppendLine("Pais de origen: " + this.paisOrigen);
            
            return ret.ToString();
        }


        public override string ToString()
        {
            return this.FrutaToString();
        }

    }
}
