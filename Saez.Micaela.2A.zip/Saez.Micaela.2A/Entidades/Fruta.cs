﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Fruta
    {
        protected ConsoleColor _color;
        protected float _peso;

        public abstract bool TieneCarozo { get; }


        public Fruta(float peso, ConsoleColor color)
        {
            this._color = color;
            this._peso = peso;
        }


        protected virtual string FrutaToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.AppendLine("Color: " + this._color);
            ret.AppendLine("Peso: " + this._peso);
            ret.Append("Tiene carozo: " + this.TieneCarozo);
            
            return ret.ToString();
        }


    }
}
