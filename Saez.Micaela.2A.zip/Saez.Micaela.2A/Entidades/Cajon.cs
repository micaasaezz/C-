﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;

namespace Entidades
{
    public delegate void CajonDelegado(object objeto, EventArgs evento);

    public class Cajon <T> : ISerializable
    {
        private int _capacidad;
        private List<T> _frutas;
        private float _precioUnitario;

        public List<T> Frutas 
        {
            get { return this._frutas; }
        }
        public float PrecioTotal 
        {
            get 
            {
                if (this._precioUnitario > 25)
                {
                    Manejador(this._precioUnitario, new EventArgs());
                    this.EventoPrecio = new CajonDelegado(Manejador);
                }
                return this._precioUnitario;
            }
        }
        public string RutaArchivo 
        {
            get { return @"\ArchivoCajonSerializado.xml"; }
            set { this.RutaArchivo = this.RutaArchivo; }
        }


        public Cajon()
        {
            this._frutas = new List<T>();
        }
        public Cajon(int capacidad)
            :this()
        {
            this._capacidad = capacidad;
        }
        public Cajon(int capacidad, float precio)
            :this(capacidad)
        {
            this._precioUnitario = precio;
        }

        public bool SerializarXML()
        {
            TextWriter escritor = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + this.RutaArchivo, true);
            try
            {
                XmlSerializer serializador = new XmlSerializer(typeof(Cajon<T>));
                Cajon<T> obj = new Cajon<T>();
                serializador.Serialize(escritor, obj);
                
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                escritor.Close();
            }
            return true;
        }
        
        public bool DeserializarXML()
        {
            TextReader lectura = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + this.RutaArchivo, true);
            try
            {
                XmlSerializer deserializador = new XmlSerializer(typeof(Cajon<T>));
                deserializador.Deserialize(lectura);
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                lectura.Close();
            }

            return true;
        }


        public override string ToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.AppendLine("Capacidad del cajon: " + this._capacidad);
            ret.AppendLine("Cantidad de frutas: " + this._frutas.Count);
            ret.AppendLine("Precio total: " + this._precioUnitario);
            foreach (T item in this._frutas)
            {
                ret.AppendLine(item.ToString());
            }
            
            return ret.ToString();
        }

        public static Cajon<T> operator +(Cajon<T> cajon, T fruta)
        {
            Cajon<T> cajonNuevo = new Cajon<T>();
            cajonNuevo = cajon;
            if (cajon._capacidad > cajon._frutas.Count)
            {
                cajon._frutas.Add(fruta);
            }
            else
            {
                throw new CajonLlenoException("La capacidad " + cajonNuevo._frutas.Count + " se alcanzo!");
            }

            return cajonNuevo;
        }

        public event CajonDelegado EventoPrecio;


        public static void Manejador(object objeto, EventArgs evento)
        {
            StreamWriter escritor = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + @"\archivo.txt", true);
            try
            {
                DateTime fecha = DateTime.Now;
                escritor.WriteLine(fecha.ToString() + " - Precio Total: "+ ((float)objeto).ToString());
            }
            catch (Exception)
            {

            }

            escritor.Close();
        }

    }
}
