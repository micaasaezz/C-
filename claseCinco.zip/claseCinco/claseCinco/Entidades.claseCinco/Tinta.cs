﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.claseCinco
{
    public class Tinta
    {
        private ConsoleColor _color;
        private EtipoTinta _tipo;

        public Tinta()
        {
            this._color = ConsoleColor.Black;
            this._tipo = EtipoTinta.Comun;
        }

        public Tinta(ConsoleColor color) : this() 
        {
            this._color = color;
        }
        
        public Tinta(ConsoleColor color, EtipoTinta tinta) : this(color)
        {
            this._tipo = tinta;
        }


        private string Mostrar()
        {
            return "Color: " + this._color + "\nTipo de tinta: " + this._tipo;
        }

        public static string Mostrar(Tinta objeto)
        {
            return objeto.Mostrar(); 
        }



        //sobrecarga de operadores
        
        //operador ==
        public static bool operator ==(Tinta obj1, Tinta obj2)
        {
            //bool esIgual = false;

            //if (obj1._color == obj2._color && obj1._tipo == obj2._tipo)
            //{
            //    esIgual = true; 
            //}

            //return esIgual;

            return obj1._tipo == obj2._tipo && obj1._color == obj2._color;
        }

        public static bool operator !=(Tinta obj1, Tinta obj2)
        {
            //bool esDistinto = true;

            //if (obj1 == obj2)
            //{
            //    esDistinto = false;
            //}
           
            //return esDistinto;

            return !(obj1 == obj2);
        }


        //public static explicit operator string (Tinta tinta)
        //{
        //    return tinta.Mostrar();
        //}

        public static implicit operator string(Tinta tinta)
        {
            return tinta._tipo.ToString();
        }

    }

}
