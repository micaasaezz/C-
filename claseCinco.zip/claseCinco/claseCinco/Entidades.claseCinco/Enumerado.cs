﻿public enum EtipoTinta
{
    Comun, China, ConBrillito
}