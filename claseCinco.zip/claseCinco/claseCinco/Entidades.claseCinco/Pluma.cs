﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.claseCinco
{
    public class Pluma
    {
        private string _marca;
        private Tinta _tinta;
        private int _cantidad;



        public Pluma()
        {
            this._marca = "Sin marca";
            this._tinta = null; ;
            this._cantidad = 0;
        }

        public Pluma(string marca) :this()
        {
            this._marca = marca;
        }

        public Pluma(string marca, int cantidad) :this(marca)
        {
            this._cantidad = cantidad;
        }

        public Pluma(string marca, int cantidad, Tinta tinta) :this(marca, cantidad)
        {
            this._tinta = tinta; 
        }



        private string Mostrar()
        {
            return "La marca es: " + this._marca + "\nLa cantidad es: " + this._cantidad + "\nLa tinta es: " + Tinta.Mostrar(this._tinta);
        }


        public static bool operator ==(Pluma pluma, Tinta tinta)
        {
            return pluma._tinta == tinta;
        }
        public static bool operator !=(Pluma pluma, Tinta tinta)
        {
            return !(pluma._tinta == tinta);
        }

        public static Pluma operator +(Pluma pluma, Tinta tinta)
        {
            if (pluma == tinta && pluma._cantidad < 100)
            {
                pluma._cantidad++;
            }

            return pluma;
        }
        public static Pluma operator -(Pluma pluma, Tinta tinta)
        {
            if (pluma == tinta && pluma._cantidad > 0)
            {
                pluma._cantidad--;
            }

            return pluma;
        }


        public static implicit operator string(Pluma pluma)
        {
            return pluma.ToString();
        }






    }
}
