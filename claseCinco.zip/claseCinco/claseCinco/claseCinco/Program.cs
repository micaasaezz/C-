﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Entidades.claseCinco;

namespace claseCinco
{
    class Program
    {
        static void Main(string[] args)
        {
            Tinta objeto = new Tinta();
            Tinta objeto2 = new Tinta(ConsoleColor.DarkMagenta, EtipoTinta.ConBrillito);
            Tinta objeto3 = new Tinta(ConsoleColor.DarkBlue, EtipoTinta.China);

            if (objeto3 == objeto2)
            {
                Console.WriteLine("2 y 3 son iguales");
            }
            else
            {
                Console.WriteLine("2 y 3 no son iguales");
            }



            Console.WriteLine(Tinta.Mostrar(objeto));
            Console.WriteLine(Tinta.Mostrar(objeto2));
            Console.WriteLine(Tinta.Mostrar(objeto3));

            Console.WriteLine();
            //Console.WriteLine((string)objeto3);
            Console.WriteLine();
            Console.WriteLine((string)objeto2);

            Console.ReadLine();
            
        }
    }
}
