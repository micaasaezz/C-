﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Centralita
    {
        private List<Llamada> _listaDeLlamadas;
        protected string _razonSocial;


        public float GananciaPorLocal { get { return this.CalcularGanancia(TipoLlamada.Local);  } }
        public float GananciaPorProvincial { get { return this.CalcularGanancia(TipoLlamada.Provincial); } }
        public float GananciaTotal { get { return this.CalcularGanancia(TipoLlamada.Todas); } }
        public List<Llamada> Llamadas { get { return this._listaDeLlamadas; } }


        public Centralita()
        {
            this._listaDeLlamadas = new List<Llamada>();
        }
        public Centralita(string nombreEmpresa) : this()
        {
            this._razonSocial = nombreEmpresa;
        }


        private float CalcularGanancia(TipoLlamada tipo)
        {
            float gananciaLocal = 0;
            float gananciaProvincial = 0;
            float gananciaTotal = 0;
            float ret = 0;

            foreach (Llamada i in this._listaDeLlamadas)
            {
                if (i is Local)
                {
                    gananciaLocal += ((Local)i).CostoLlamada;
                }
                else if (i is Provincial)
                {
                    gananciaProvincial += ((Provincial)i).CostoLlamada; 
                }

            }
            gananciaTotal = gananciaLocal + gananciaProvincial;

            switch (tipo)
            {
                case TipoLlamada.Local:
                    ret = gananciaLocal;
                    break;
                case TipoLlamada.Provincial:
                    ret = gananciaProvincial;
                    break;
                case TipoLlamada.Todas:
                    ret = gananciaTotal;
                    break;
            }

            return ret;
            
        }

        public string Mostrar()
        {
            StringBuilder ret = new StringBuilder();
            ret.Append("Razon social: ");
            ret.AppendLine(this._razonSocial);
            ret.Append("Ganancia total: ");
            ret.AppendLine(this.GananciaTotal.ToString());

 
        }
    }
}
