﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Llamada
    {
        protected float _duracion;
        protected string _nroDestino;
        protected string _nroOrigen;


        public float Duracion 
        {
            get { return this._duracion; } 
        }
        public string NroDestino
        {
            get { return this._nroDestino; }
        }
        public string NroOrigen
        {
            get { return this._nroOrigen; }
        }

        
        public Llamada(string origen, string destino, float duracion)
        {
            this._nroOrigen = origen;
            this._duracion = duracion;
            this._nroDestino = destino;
        }

        public string Mostrar()
        {
            StringBuilder ret = new StringBuilder();

            ret.Append("Duracion: ");
            ret.AppendLine(this.Duracion.ToString());
            ret.Append("Nro. Origen: ");
            ret.AppendLine(this.NroOrigen);
            ret.Append("Nro. Destino: ");
            ret.AppendLine(this.NroDestino);

            return ret.ToString();
        }

        public static int OrdenarPorDuracion(Llamada uno, Llamada dos)
        {
            int ret = 0;
            if (uno.Duracion > dos.Duracion)
            {
                ret = 1;
            }
            else if (uno.Duracion < dos.Duracion)
            {
                ret = 1;
            }

            return ret;
        }


    }
}
