﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Local : Llamada
    {
        protected float _costo;


        public float CostoLlamada
        {
            get { return this._costo; }
        }

        

        public Local (Llamada unaLlamada, float costo) : this(unaLlamada.NroOrigen, unaLlamada.Duracion, unaLlamada.NroDestino, costo)
        {

        }
        public Local(string origen, float duracion, string destino, float costo) : base(origen, destino, duracion)
        {
            this._costo = costo; 
        }
        
        
        private float CalcularCosto()
        {
            return this._costo * base.Duracion;
        }

        public string Mostrar()
        {
            StringBuilder ret = new StringBuilder();

            ret.AppendLine(base.Mostrar());
            ret.Append("Costo: ");
            ret.AppendLine(this.CostoLlamada.ToString());

            return ret.ToString();
        }
    }
}
