﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace claseTres
{
    class Program
    {
        static void Main(string[] args)
        {
            Auto primerAuto = new Auto();
            Auto segundoAuto = new Auto();
            TimeSpan tiempoTotal;

            primerAuto.marca = "fiat";
            primerAuto.precio = 130000;
            primerAuto.patente = "a001";

            segundoAuto.patente = "b002";
            segundoAuto.marca = "ford";
            segundoAuto.precio = 80000;

            primerAuto = segundoAuto; //se pueden asignar porque son del mismo tipo

            Console.WriteLine("Primer auto:");
            Console.WriteLine(Auto.Mostrar(primerAuto));
            Console.WriteLine("\nSegundo auto:");
            Console.WriteLine(Auto.Mostrar(segundoAuto));

            Console.WriteLine("\nCantidad de autos: " + Auto.cantInstancias);
            Console.WriteLine("\nLa fecha de inicio fue: {0}\nLa fecha del ultimo fue: {1}", Auto.f_inicio, Auto.f_ultimo);
            
            tiempoTotal = Auto.f_ultimo - Auto.f_inicio; //la resta de dos DateTime es de tipo TimeExpand
            Console.WriteLine("\nLa diferencia de tiempo entre el primero y el ultimo es: " + tiempoTotal.Milliseconds + " millisegundos."); 
            

            Console.Read();

            /*
            
            *atributos: 
            - static (clase)
            - no static (instancia)
            
            *metodos:
            - static (clase)
            - no static (instancia)
            
            *constructores: // se ejecutan una sola vez por objeto
            - static (clase)  
             . modelo de un constructor estatico:  static Auto() {}
             . no llevan modificadores de visibilidad 
             . no reciben parametros
             . mismo nombre de la clase como los constructores de instancia
             . sirven para inicializar atributos estaticos
             . se ejecuta una sola vez por proyecto que es la misma que la 
             primera que el constructor de instancia
             . se ejecuta antes que el constructor de instancia
            
            - no static (instancia)
             . inicializa los atributos no estaticos (de instancia)
            
            */

        }
    }
}
