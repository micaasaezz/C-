﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace claseTres
{
    class Auto
    {
        //instancias 
        public string marca;
        public string patente;
        public float precio;

        //instancias de clase
        public static int cantInstancias; //no es necesario inicializarlo a 0, se inicia solo en 0 por default
        public static DateTime f_inicio;
        public static DateTime f_ultimo;

        private string Mostrar()
        {
            //string resultado;

            //resultado = "Marca: " + this.marca + "\nPatente: " + this.patente + "\nPrecio: " + this.precio;

            return "Marca: " + this.marca + "\nPatente: " + this.patente + "\nPrecio: " + this.precio; 
        }
        //this solo para metodos no estaticos
        //hace referencia al objeto que esta ejecutando actualmente el codigo
        //this.marca  marca es una instancia de this

        public static string Mostrar(Auto auto)
        {

            //return "Marca: " + auto.marca + "\nPatente: " + auto.patente + "\nPrecio: " + auto.precio; 
            return auto.Mostrar(); //llama a la funcion privada
        }


        public Auto()
        {
            //se podrian inicializar atributos

            /*if (Auto.cantInstancias == 0)
            {
                Auto.f_inicio = DateTime.Now;

            }*/
           
            Auto.f_ultimo = DateTime.Now;
           
            Auto.cantInstancias++;

        }

        static Auto() 
        {
            Auto.f_inicio = DateTime.Now;
        }



    }
}
