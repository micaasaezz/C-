﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Lavadero
    {
        private List<Vehiculo> _listaVehiculos;
        private static float _precioAuto;
        private static float _precioCamion;
        private static float _precioMoto;
        private string _razonSocial;


        public string Lavaderos 
        {   get 
            {
                StringBuilder ret = new StringBuilder();
                ret.Append("Razon social: ");
                ret.AppendLine(this._razonSocial);
                ret.Append("Precio auto: ");
                ret.AppendLine(Lavadero._precioAuto.ToString());
                ret.Append("Precio moto: ");
                ret.AppendLine(Lavadero._precioMoto.ToString());
                ret.Append("Precio camion: ");
                ret.AppendLine(Lavadero._precioCamion.ToString());
                ret.AppendLine("Vehiculos: ");
                ret.AppendLine(this.Vehiculos);

                return ret.ToString();
                    
            }
        }

        public string Vehiculos
        {   get
            {
                StringBuilder ret = new StringBuilder();
                foreach (Vehiculo i in this._listaVehiculos)
                {
                    ret.AppendLine(i.ToString());
                    ret.AppendLine("************");
                }

                return ret.ToString();
            }
        }

        private Lavadero()
        {
            this._listaVehiculos = new List<Vehiculo>();
        }


        public Lavadero(string razonSocial) :this()
        {
            this._razonSocial = razonSocial;
        }

        static Lavadero()
        {
            Random precio = new Random();
            Lavadero._precioAuto = precio.Next(150, 565);
            Lavadero._precioCamion = precio.Next(150, 565);
            while (Lavadero._precioCamion == Lavadero._precioAuto)
            {
                Lavadero._precioCamion = precio.Next(150, 565); 
            }
            Lavadero._precioMoto = precio.Next(150, 565);
            while (Lavadero._precioMoto == Lavadero._precioAuto || Lavadero._precioMoto == Lavadero._precioCamion)
            {
                Lavadero._precioMoto = precio.Next(150, 565);
            }
        }

        




        private double MostrarTotalFacturado()
        {
            return MostrarTotalFacturado(eVehiculo.Auto) + MostrarTotalFacturado(eVehiculo.Camión) + MostrarTotalFacturado(eVehiculo.Moto); 
        }


        private double MostrarTotalFacturado(eVehiculo vehiculo)
        {
            double total = 0;
            double contadorAutos = 0;
            double contadorMotos = 0;
            double contadorCamion = 0;

            foreach (Vehiculo i in this._listaVehiculos)
            {
                if (i is Auto)
                {
                    contadorAutos++;
                }
                else if (i is Camion)
                {
                    contadorCamion++;
                }
                else if (i is Moto)
                {
                    contadorMotos++;
                }

            }

            switch (vehiculo)
            {
                case eVehiculo.Auto:
                    total = contadorAutos * Lavadero._precioAuto;
                    break;
                case eVehiculo.Camión:
                    total = contadorCamion * Lavadero._precioCamion;
                    break;
                case eVehiculo.Moto:
                    total = contadorMotos * Lavadero._precioMoto;
                    break;
            }
            return total;
        }





        public static bool operator ==(Vehiculo vehiculo, Lavadero lavadero)
        {
            bool esta = false;
            foreach (Vehiculo i in lavadero._listaVehiculos)
            {
                if (i == vehiculo)
                {
                    esta = true;
                    break;
                }
            }
            return esta;
        }
        public static int operator ==(Lavadero lavadero, Vehiculo vehiculo)
        {
            int ret = -1;
            if (vehiculo == lavadero)
            {
                for (int i = 0; i < lavadero._listaVehiculos.Count; i++)
                {
                    if (lavadero._listaVehiculos[i] == vehiculo)
                    {
                        ret = i;
                        break;
                    }
                }
            }

            return ret;
        }
        public static bool operator !=(Vehiculo vehiculo, Lavadero lavadero)
        {
            return !(vehiculo == lavadero);
        }



        public static Lavadero operator +(Vehiculo vehiculo, Lavadero lavadero)
        {
            Lavadero aux = new Lavadero(lavadero._razonSocial);
            aux._listaVehiculos = lavadero._listaVehiculos;
            if (vehiculo != aux)
            {
                aux._listaVehiculos.Add(vehiculo);
            }

            return aux;
        }


        public static Lavadero operator -(Vehiculo vehiculo, Lavadero lavadero)
        {
            if (lavadero == vehiculo)
            {
                 
            }
        }



    }
}
