﻿public enum eMarca
{
    Honda, Ford, Zanella, Scania, Iveco, Fiat
}

public enum eVehiculo
{
    Auto, Camión, Moto
}