﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Vehiculo
    {
        protected string _patente;
        protected byte _cantRuedas;
        protected eMarca _marca;

        public string Patente { get { return this._patente; } }
        public byte Ruedas { get { return this._cantRuedas; } }
        public eMarca Marca { get { return this._marca; } }

        public Vehiculo(string patente, byte ruedas, eMarca marca)
        {
            this._marca = marca;
            this._patente = patente;
            this._cantRuedas = ruedas;
        }

        private string Mostrar()
        {
            StringBuilder ret = new StringBuilder();
            ret.Append("Patente: ");
            ret.AppendLine(this._patente);
            ret.Append("Cant Ruedas: ");
            ret.AppendLine(this._cantRuedas.ToString());
            ret.Append("Marca: ");
            ret.AppendLine(this._marca.ToString());

            return ret.ToString();
        }


        public override string ToString()
        {
            return this.Mostrar();
        }

        
        public static bool operator ==(Vehiculo uno, Vehiculo dos)
        {
            return uno._patente == dos._patente;
        }
        public static bool operator !=(Vehiculo uno, Vehiculo dos)
        {
            return !(uno == dos);
        }



    }
}
