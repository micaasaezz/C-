﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Auto : Vehiculo
    {
        protected int _cantidadAsientos;


        public override string ToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.AppendLine(base.ToString());
            ret.Append("Cant de asientos: ");
            ret.AppendLine(this._cantidadAsientos.ToString());

            return ret.ToString();
        }


        public Auto(int asientos, string patente, byte ruedas, eMarca marca)
            :base(patente, ruedas, marca)
        {
            this._cantidadAsientos = asientos;
        }


        public Auto(string patente, eMarca marca, int asientos)
            :this(asientos, patente, 4, marca)
        {
 
        }


    }
}
