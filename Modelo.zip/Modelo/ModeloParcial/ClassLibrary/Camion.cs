﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Camion : Vehiculo
    {
        protected float _tara;


        public override string ToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.AppendLine(base.ToString());
            ret.Append("Tara: ");
            ret.AppendLine(this._tara.ToString());

            return ret.ToString();
        }


        public Camion(float tara, string patente, byte ruedas, eMarca marca)
            : base(patente, ruedas, marca)
        {
            this._tara = tara; 
        }

        public Camion(Vehiculo vehiculo, float tara)
            :this(tara, vehiculo.Patente, vehiculo.Ruedas, vehiculo.Marca)
        {
 
        }

    }
}
