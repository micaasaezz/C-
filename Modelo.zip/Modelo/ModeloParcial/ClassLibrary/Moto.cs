﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Moto : Vehiculo
    {
        protected float _cilindrada;

        public override string ToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.AppendLine(base.ToString());
            ret.Append("Cilindrada: ");
            ret.AppendLine(this._cilindrada.ToString());
            return ret.ToString();
        }


        public Moto(string patente, byte ruedas, eMarca marca, float cilindrada)
            : base(patente, ruedas, marca)
        {
            this._cilindrada = cilindrada;
        }

        public Moto(eMarca marca, string patente, float cilindrada, byte ruedas)
            : this(patente, ruedas, marca, cilindrada)
        {
 
        }



    }
}
