﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CentralitaHerencia;

namespace CentralitaWindowsForms
{
    public partial class FrmLlamada : Form
    {
        public FrmLlamada()
        {
            InitializeComponent();
        }

        protected void Llamada_Load(object sender, EventArgs e)
        {

        }

        protected virtual void label2_Click(object sender, EventArgs e)
        {

        }

        protected virtual void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        protected virtual void btnAceptar_Click(object sender, EventArgs e)
        {
            Llamada llamada = new Llamada(this.textBox1.Text, this.textBox2.Text, float.Parse(this.txtDuracion.Text));
            

            this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }

        protected virtual void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        protected virtual void txtDuracion_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
