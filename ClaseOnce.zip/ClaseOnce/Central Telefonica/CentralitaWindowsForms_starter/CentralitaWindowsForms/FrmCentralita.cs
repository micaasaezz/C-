﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CentralitaHerencia;

namespace CentralitaWindowsForms
{
    public partial class FrmCentralita : Form
    {
        public FrmCentralita()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmLocal frmLocal = new FrmLocal();
            frmLocal.ShowDialog();
            if (this.DialogResult == System.Windows.Forms.DialogResult.OK)
            {
                
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmProvincial frmProvincial = new FrmProvincial();
            frmProvincial.ShowDialog();
            if (this.DialogResult == System.Windows.Forms.DialogResult.OK)
            {
 
            }
        }
    }
}
