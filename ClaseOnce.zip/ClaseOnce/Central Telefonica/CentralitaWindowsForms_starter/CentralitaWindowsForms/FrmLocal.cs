﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CentralitaHerencia;

namespace CentralitaWindowsForms
{
    public partial class FrmLocal : FrmLlamada
    {
        private Local _llamadaLocal;

        //public FrmLocal LlamadaLocal { get { return this._llamadaLocal; } }


        public FrmLocal()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        protected void btnAceptar_Click_1(object sender, EventArgs e)
        {
            this._llamadaLocal._costo = float.Parse(this.textBox3.Text);
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

    }
}
