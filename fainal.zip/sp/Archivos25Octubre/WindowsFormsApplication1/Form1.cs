﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using ClassLibrary1;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        protected Persona _persona;
        protected OpenFileDialog _openArchivo;
        protected SaveFileDialog _saveArchivo;

        public Form1()
        {
            InitializeComponent();
            this._persona = new Persona("Micaela", "Saez");            
        }

        private void guardarToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        //guardar
        private void guardarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this._saveArchivo = new SaveFileDialog();
            this._saveArchivo.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            
            if (this._saveArchivo.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                StreamWriter escritor = new StreamWriter(this._saveArchivo.FileName, true);
                escritor.WriteLine(this._persona.ToString());
                escritor.Close(); 
            }
            
        }
        //leer
        private void leerToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this._openArchivo = new OpenFileDialog();
            
            if (this._openArchivo.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                string mensaje = "";
                StreamReader lector = new StreamReader(this._openArchivo.FileName);
                while (lector.EndOfStream == false)
                {
                    mensaje += lector.ReadLine(); 
                }
                MessageBox.Show(mensaje);
                lector.Close();
            }

        }
    }
}
