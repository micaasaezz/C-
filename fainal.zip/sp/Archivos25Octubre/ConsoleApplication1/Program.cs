﻿using System;
using System.IO; // archivos de texto streamwriter/reader
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization; //archivos xml
using System.Threading.Tasks;
using ClassLibrary1;

namespace ConsoleApplication1
{
    
    class Program
    {
        static void Main(string[] args)
        {
            Persona persona = new Persona("Mica", "Saez");
            /*
            StreamWriter archivoEscritura = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + @"\persona.txt", true);
            //el parametro true es para que se pueda escribir sin sobrescribir
            archivoEscritura.WriteLine(persona.ToString());
            archivoEscritura.Close();
            
            //StreamReader archivoLectura = new StreamReader(@"D:\personas.txt");
            //Console.WriteLine(archivoLectura.ReadToEnd());
            //archivoLectura.Close();

            string linea = "";
            //StreamReader l = new StreamReader(@"D:\personas.txt");  
            //para guardarlo en bin/degub del la app .exe
            //StreamReader l = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + @"\persona.txt");
            StreamReader l = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + @"\persona.txt");            
            //while((linea=l.ReadLine())!=null){Console.WriteLine(linea);}
            while(! l.EndOfStream)
            {
                linea = l.ReadLine();
                Console.WriteLine(linea);
            }
            l.Close();

            //Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
            //bloque using, al salir cierra lo que se use using(tipo identificador = new tipo())
            using(StreamReader r = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + @"\persona.txt"))
            {
                while (r.EndOfStream == false)
                {
                    linea = r.ReadLine();
                    Console.WriteLine(linea);
                }
            }


            //StreamWriter writer = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + @"\ejemplo.txt", true);
            Console.Read();
            */

            //ARCHIVOS XML - archivos de texto con una extension particular

            TextReader lector;
            TextWriter escritor;

            XmlSerializer serializador = new XmlSerializer(typeof(Persona));
            //la clase a serializar debe ser publica y tener un constructor por defecto

            escritor = new StreamWriter(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\personas.xml");
            serializador.Serialize(escritor, persona);
            //escritor.WriteLine(persona.ToString());
            escritor.Close();

            lector = new StreamReader(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\personas.xml");

            Persona p = (Persona) serializador.Deserialize(lector);
            Console.WriteLine(p.ToString());

            List<Persona> lista = new List<Persona>();
            Persona p1 = new Persona("Mica", "Saez");
            Persona p2 = new Persona("Persona", "Dos");
            Persona p3 = new Persona("Persona", "Tres");
            lista.Add(p1);
            lista.Add(p2);
            lista.Add(p3);

            XmlSerializer serializadorLista = new XmlSerializer(typeof(List<Persona>));
            TextWriter escritorLista = new StreamWriter(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\lista.xml");
            serializadorLista.Serialize(escritorLista, lista);
            escritorLista.Close();

            TextReader lectorLista = new StreamReader(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\lista.xml");
            List<Persona> listaDos = (List<Persona>)serializadorLista.Deserialize(lectorLista);
            

            for (int i = 0; i < listaDos.Count; i++)
            {
                Console.WriteLine(listaDos[i].ToString());
            }

            Console.Read();

        }
    }
}
