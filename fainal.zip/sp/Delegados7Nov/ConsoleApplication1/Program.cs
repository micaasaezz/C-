﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;

namespace ConsoleApplication1
{
    class Program
    {
        //metodo con la misma firma que el delegado
        static void Manejador() //manejador de eventos estatico o de clase
        {
            Console.WriteLine("Estoy en el manejador del limite sueldo"); 
        }

        void ManejadorDos() //manejador de eventos de instancia
        {
            Console.WriteLine("Estoy en el manejador 2 del limite sueldo"); 
        }


        void ManejadorEmpleado(Empleado e)
        {
            Console.WriteLine("Empleado que se quiso subir el sueldo:");
            Console.WriteLine(e.ToString());
        }


        void ManejadorEmpleadoSueldo(Empleado e, double sueldo)
        {
            Console.WriteLine("Empleado:");
            Console.WriteLine(e.ToString());
            Console.WriteLine("Sueldo que se quiso poner: " + sueldo.ToString());
        }


        void ManejadorEmpleadoSueldo2(object o, EmpleadoEventArgs e)
        {
            Console.WriteLine("Manejador con EventArgs: \nEmpleado:");
            Console.WriteLine(((Empleado)o).ToString());
            Console.WriteLine("Sueldo que se quiso poner: " + e.sueldo);

            Program p = new Program();
            ((Empleado)o).LimiteEmpleadoSueldo2 -= new DelEmpleadoSueldo2(p.ManejadorEmpleadoSueldo2);
        }



        static void Main(string[] args)
        {
            Empleado e = new Empleado();
            
            //configuracion del delegado
            //un evento puede tener asociados varios metodos
            //en el constructor se le pasa la dir de mem del metodo 
            //que tenga la misma firma que el delegado
            
            e.LimiteSueldo += new DelEmpl(Manejador); //manejador estatico o de clase
            
            Program p = new Program(); 
            e.LimiteSueldo += new DelEmpl(p.ManejadorDos); //manejador de instancia

            e.LimiteSueldoEmpleado += new DelEmplConEmpleado(p.ManejadorEmpleado);

            e.LimiteSueldoEmpleadoySueldo += new DelEmplConEmpleadoYSueldo(p.ManejadorEmpleadoSueldo);

            e.LimiteEmpleadoSueldo2 += new DelEmpleadoSueldo2(p.ManejadorEmpleadoSueldo2);

            try
            {
                e.Nombre = "Mica";
                e.Apellido = "Saez";
                e.Sueldo = 9501;
                //Console.WriteLine(e.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            
            //DELEGADOS
            //un delegado esta en medio de quien emite un evento y quien lo recive
            //emisor (lanza un evento) -> delegado -> receptor (metodo)
            //el receptor atrapa al evento con un metodo
            //ejemplo tocar un boton en un wforms
            //un delegado es un puntero a funcion que no necesita estar en la misma clase
            //el objeto delegado debe ser visible por el emisor y el receptor


            Console.Read();
        }
    }
}
