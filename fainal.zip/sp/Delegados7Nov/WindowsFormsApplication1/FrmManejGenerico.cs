﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class FrmManejGenerico : Form
    {
        public FrmManejGenerico()
        {
            InitializeComponent();

            this.label1.Click += new EventHandler(this.ManejadorGenerico);
            this.button1.Click += new EventHandler(this.ManejadorGenerico);
            this.textBox1.Click += new EventHandler(this.ManejadorGenerico);

        }

        void ManejadorGenerico(object obj, EventArgs eventos)
        {
            if (obj is TextBox)
            {
                ((TextBox)obj).ForeColor = Color.Red;
                ((TextBox)obj).Font = new Font("Tahoma", 18);
                
            }
            else if (obj is Label)
            {
                ((Label)obj).FlatStyle = FlatStyle.Flat;
                ((Label)obj).BorderStyle = BorderStyle.Fixed3D;

            }
            else if (obj is Button)
            {
                ((Button)obj).Location = new Point(0, 0); 
            }

            
            /*
            List<Control> controls = new List<Control>();
            foreach (Control item in controls)
            {
                item.Click += new EventHandler(ManejadorGenerico); 
            }    
            */

            MessageBox.Show("Invocado por "+ obj.GetType().Name);
        }


    }
}
