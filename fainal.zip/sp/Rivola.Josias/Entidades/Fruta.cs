﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;//new
using System.IO;//new

namespace Entidades
{
    [XmlInclude(typeof(Manzana))]
    [XmlInclude(typeof(Platano))]

    static class Class1
    {
        public static string Translate(this ConsoleColor color)
        {
            string retorno = "";
            switch (color)
            {
                case ConsoleColor.Black:
                    retorno = "Negro";
                    break;
                case ConsoleColor.Blue:
                    retorno = "Azul";
                    break;
                case ConsoleColor.Cyan:
                    retorno = "Cian";
                    break;
                case ConsoleColor.DarkBlue:
                    retorno = "Azul oscuro";
                    break;
                case ConsoleColor.DarkCyan:
                    retorno = "Cian oscuro";
                    break;
                case ConsoleColor.DarkGray:
                    retorno = "Gris oscuro";
                    break;
                case ConsoleColor.DarkGreen:
                    retorno = "Verde oscuro";
                    break;
                case ConsoleColor.DarkMagenta:
                    retorno = "Magenta oscuro";
                    break;
                case ConsoleColor.DarkRed:
                    retorno = "Rojo oscuro";
                    break;
                case ConsoleColor.DarkYellow:
                    retorno = "Amarillo oscuro";
                    break;
                case ConsoleColor.Gray:
                    retorno = "Gris";
                    break;
                case ConsoleColor.Green:
                    retorno = "Verde";
                    break;
                case ConsoleColor.Magenta:
                    retorno = "Magenta";
                    break;
                case ConsoleColor.Red:
                    retorno = "Rojo";
                    break;
                case ConsoleColor.White:
                    retorno = "Blanco";
                    break;
                case ConsoleColor.Yellow:
                    retorno = "Amarillo";
                    break;
                default:
                    break;
            }
            return retorno;
        }
    }

    public abstract class Fruta
    {
        #region Atributos
        protected ConsoleColor _color;
        protected float _peso;
        #endregion

        public Fruta() { }

        public Fruta(float peso, ConsoleColor color)
        {
            this._color = color;
            this._peso = peso;
        }
        public abstract bool TieneCarozo { get; }

        protected virtual string FrutaToString()
        {
            return "Color: " + this._color.Translate() + "\nPeso: " + this._peso.ToString() + "\nTiene Carozo: " + (this.TieneCarozo == true ? "SI" : "NO");
        }

    }
}
