﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public interface IInterface
    {
        void serializarXml(string path);
        void deserializarXml(string path);

        void serializarBinario(string path);
        void deserializarBinario(string path);



    }
}
