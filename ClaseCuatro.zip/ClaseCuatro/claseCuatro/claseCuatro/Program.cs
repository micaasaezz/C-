﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace claseCuatro
{
    class Program
    {
        static void Main(string[] args)
        {
            //Cosa obj = new Cosa(3, "lalala");
            //Cosa obj = new Cosa(DateTime.Now, "lalala", 3);
            Cosa obj = new Cosa();
            Cosa obj2 = new Cosa();
            obj2.EstablecerValor(ConsoleColor.DarkCyan);
            Console.WriteLine(obj2.Mostrar());
            DateTime fecha = new DateTime(2014, 05, 21, 19, 30, 02);
            //ConsoleColor color = ConsoleColor.DarkRed;

            Console.WriteLine(obj.Mostrar(obj.cadena));
            Console.WriteLine(obj.Mostrar(obj.entero));
            Console.WriteLine(obj.Mostrar(obj.fecha));

            obj.EstablecerValor(DateTime.Now);
            obj.EstablecerValor("string");
            obj.EstablecerValor(123);
            obj.EstablecerValor(ConsoleColor.DarkRed);

            Console.WriteLine(obj.Mostrar());
            
            //Console.WriteLine(obj.Mostrar(obj.cadena));
            //Console.WriteLine(obj.Mostrar(obj.entero));
            //Console.WriteLine(obj.Mostrar(obj.fecha));
            //Console.WriteLine(obj.Mostrar(fecha));

            Console.ReadLine();

        }
    }
}
