﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace claseCuatro
{
    class Cosa
    {
        public int entero;
        public string cadena;
        public DateTime fecha;
        ConsoleColor color;


        public void EstablecerValor(ConsoleColor color)
        {
            this.color = color;
           
        }

        /// <summary>
        /// Establece el valor del entero en el objeto
        /// </summary>
        /// <param name="entero"></param>
        public void EstablecerValor(int entero)
        {
            this.entero = entero;
        }
        /// <summary>
        /// Establece el valor del string en el objeto
        /// </summary>
        /// <param name="cadena"></param>
        public void EstablecerValor(string cadena)
        {
            this.cadena = cadena;
        }
        /// <summary>
        /// Establece el valor de la fecha en el objeto
        /// </summary>
        /// <param name="fecha"></param>
        public void EstablecerValor(DateTime fecha)
        {
            this.fecha = fecha;
        }

        /// <summary>
        /// Muestra el valor del entero
        /// </summary>
        /// <param name="entero"></param>
        /// <returns></returns>
        public string Mostrar(int entero)
        {
            return "El entero es: " + entero;
        }
        /// <summary>
        /// Muestra el valor del string
        /// </summary>
        /// <param name="cadena"></param>
        /// <returns></returns>
        public string Mostrar(string cadena)
        {
            return "La cadena es: " + cadena;
        }
        /// <summary>
        /// Muestra el valor de la fecha
        /// </summary>
        /// <param name="fecha"></param>
        /// <returns></returns>
        public string Mostrar(DateTime fecha)
        {
            return "La fecha es: " + fecha;
        }

        public string Mostrar()
        {
            
            Console.ForegroundColor = this.color;
            return "La fecha es: " + this.fecha+ "\nLa cadena es: " + this.cadena + "\nEl entero es: " + this.entero+"\n";

        }


        /// <summary>
        /// Inicializa el valor entero con el param entero, el string con el param cadena, y la fecha actual
        /// </summary>
        /// <param name="entero"></param>
        /// <param name="cadena"></param>
        public Cosa(int entero, string cadena) : this (entero)
        {
            //EstablecerValor(entero);
            EstablecerValor(cadena); //this.cadena = cadena;
            //EstablecerValor(DateTime.Now);
        }
        /// <summary>
        /// Inicializa el valor entero con el param entero, el string sin valor, y la fecha actual 
        /// </summary>
        /// <param name="entero"></param>
        public Cosa(int entero) : this()
        {
            EstablecerValor(entero); //this.entero = entero;
            //EstablecerValor("Sin valor");
            //EstablecerValor(DateTime.Now);
        }
        /// <summary>
        /// Constructor por defecto
        /// </summary>
        public Cosa() 
        {
            this.fecha = DateTime.Now;
            this.entero = 0;
            this.cadena = "sin valor";
            this.color = ConsoleColor.DarkGray;
        }

        public Cosa(DateTime fecha, string cadena, int entero) : this(entero, cadena)
        {
            this.fecha = fecha;
        }

    }
}
