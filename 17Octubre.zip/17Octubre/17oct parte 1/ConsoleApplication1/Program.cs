﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Avion avion = new Avion(1000, 23.3);
            Deportivo deportivo = new Deportivo(1000, "aaa222", 4);

            Console.WriteLine("Impuesto del avion: {0}", ((IAFIP) avion).CalcularImpuesto());
            Console.WriteLine("Impuesto del deportivo: {0}", ((IAFIP)deportivo).CalcularImpuesto());

            Privado avionPrivada = new Privado(10000, 23.43, 6);
            Comercial avionComercial = new Comercial(100000, 34.54, 432);

            Console.WriteLine("Impuesto avion privada: {0}", ((IAFIP)avionPrivada).CalcularImpuesto());
            Console.WriteLine("Impuesto avion comercial: {0}", ((IAFIP)avionComercial).CalcularImpuesto());

            Console.Read();
        }
    }
}
