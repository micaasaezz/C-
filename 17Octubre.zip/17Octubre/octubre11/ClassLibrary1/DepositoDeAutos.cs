﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class DepositoDeAutos
    {
        private int _capacidadMaxima;
        private List<Auto> _lista;

        public DepositoDeAutos(int capacidad)
        {
            this._capacidadMaxima = capacidad;
            this._lista = new List<Auto>();
        }


        public static bool operator +(DepositoDeAutos d, Auto a)
        {
            bool pudo = false;
            if (d._capacidadMaxima > d._lista.Count)
            {
                d._lista.Add(a);
                pudo = true;
            }
            return pudo;
        }

        private int GetIndice(Auto a)
        {
            int retorno = -1;
            for (int i = 0; i < this._lista.Count; i++)
            {
                if (this._lista[i] == a)
                {
                    retorno = i;
                    break;
                }
            }
            return retorno;
        }


        public static bool operator -(DepositoDeAutos d, Auto a)
        {
            bool pudo = false;
            if (d.GetIndice(a) != -1)
            {
                d._lista.RemoveAt(d.GetIndice(a));
                pudo = true;
            }
            return pudo;
        }

        public bool Agregar(Auto a)
        {
            return this + a; 
        }
        public bool Remover(Auto a)
        {
            return this - a;
        }


        public override string ToString()
        {
            StringBuilder ret =  new StringBuilder();
            ret.Append("Capacidad Maxima: ");
            ret.AppendLine(this._capacidadMaxima.ToString());
            ret.AppendLine("Listado de autos ");
            foreach (Auto i in this._lista)
            {
                ret.AppendLine(i.ToString());
            }
            return ret.ToString();
        }


    }
}
