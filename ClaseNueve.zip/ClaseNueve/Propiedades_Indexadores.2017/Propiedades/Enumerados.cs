﻿public enum EColor
{
    Rojo,
    Azul,
    Verde,
    Negro
}

public enum EDiaDeLaSemana
{
    Lunes = 1,
    Martes = 2,
    Miercoles = 3,
    Jueves = 4,
    Viernes = 5,
    Sabado = 6,
    Domingo = 0,

}