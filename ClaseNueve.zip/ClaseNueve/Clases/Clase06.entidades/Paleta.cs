﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase06.entidades
{
    public class Paleta
    {
        private Tempera[] _colores;
        private int _cantMaximaColores;

        private Paleta(): this(5)
        {
            //this._cantMaximaColores = 5;
            //this._colores = new Tempera[this._cantMaximaColores];
        }

        private Paleta(int cantidad)
        {
            this._cantMaximaColores = cantidad;
            this._colores = new Tempera[this._cantMaximaColores];
        }


        /// <summary>
        /// Parecido al constructor porque le da la cantidad de espacios a la paleta
        /// </summary>
        /// <param name="cantidad">Int que determina la cantidad maxima de colores que posee la paleta</param>
        /// <returns>Objeto tipo Paleta</returns>
        public static implicit operator Paleta(int cantidad)
        {
            return new Paleta(cantidad);
        }

        /// <summary>
        /// muestra los atributos de el objeto paleta y cada uno de los objetos tipo Temperas contenidos
        /// </summary>
        /// <returns>string datos </returns>
        private string Mostrar()
        {
            string mensaje = "Paleta: \nCant max colores: " + this._cantMaximaColores + " \n";

            for (int i = 0; i < this._cantMaximaColores; i++)
            {
                if (this._colores.GetValue(i) != null)
                {
                    mensaje += Tempera.Mostrar(this._colores[i]);
                }
            }
            
            return mensaje+" \n";
        }
        /// <summary>
        /// Muestra los atributos del objeto de tipo Paleta
        /// </summary>
        /// <param name="paleta">Objeto que sera mostrado</param>
        /// <returns></returns>
        public static string Mostrar(Paleta paleta)
        {
            return paleta.Mostrar();
        }

        /// <summary>
        /// Verifica si el objeto de tipo Tempera esta contenido en el objeto tipo Paleta
        /// </summary>
        /// <param name="paleta">Paleta que sera verificada</param>
        /// <param name="tempera">Tempera que sera verificada</param>
        /// <returns>True en caso de contener el objeto, False en caso contrario</returns>
        public static bool operator ==(Paleta paleta, Tempera tempera)
        {
            bool igual = false;
            for (int i = 0; i < paleta._cantMaximaColores; i++)
            {
                if (paleta._colores.GetValue(i) != null)
                {
                    if (paleta._colores[i] == tempera)
                    {
                        igual = true;
                        break;
                    }
                }
            }
            return igual;
        }


        /// <summary>
        /// Verifica si el objeto de tipo Tempera no esta contenido en el objeto tipo Paleta
        /// </summary>
        /// <param name="paleta">Paleta que sera verificada</param>
        /// <param name="tempera">Tempera que sera verificada</param>
        /// <returns>True en caso de no contener el objeto, False en caso contrario</returns>
        public static bool operator !=(Paleta paleta, Tempera tempera)
        {
            return !(paleta == tempera);
        }

        /// <summary>
        /// Suma una Tempera a una Paleta, en caso de que ya este contenida suma la cantidad
        /// </summary>
        /// <param name="paleta">Paleta a la que se agregara una tempera</param>
        /// <param name="tempera">Tempera que sera agregada</param>
        /// <returns>Paleta con la tempera agregada</returns>
        public static Paleta operator +(Paleta paleta, Tempera tempera)
        {
            if (paleta != tempera)
            {
                if(paleta.ObtenerIndice() != -1)
                {
                     paleta._colores[paleta.ObtenerIndice()] = tempera;
                }
            }
            else//el color esta en la paleta
            {
                for (int i = 0; i < paleta._cantMaximaColores; i++)
                {
                    if (paleta._colores[i] == tempera)
                    {
                        paleta._colores[i] += tempera;
                        break;
                    }
                }
                
            }
            return paleta;
        }

        /// <summary>
        /// quita una Tempera de la Paleta
        /// </summary>
        /// <param name="paleta">Paleta que contiene la tempera</param>
        /// <param name="tempera">Tempera que sera quitada</param>
        /// <returns>Paleta modificada</returns>
        public static Paleta operator -(Paleta paleta, Tempera tempera)
        {
            if (paleta == tempera)
            {
                for(int i=0;i<paleta._cantMaximaColores;i++)
                {
                    if (paleta._colores.GetValue(i) != null)
                    {
                        if (paleta._colores[i] == tempera)
                        {
                            paleta._colores[i] = null;
                            break;
                        }
                    }
                }
            }
            return paleta;
        }

        /*public static Paleta operator +(Paleta paletaUno, Paleta paletaDos)
        {
            Paleta paletaRetorno;

            return paletaRetorno;
        }
        */


        /// <summary>
        /// Obtiene el primer lugar libre [null] del array tipo Paleta
        /// </summary>
        /// <returns>[-1]en caso de que no haya lugar libre, o el indice del lugar vacio</returns>
        private int ObtenerIndice()
        {
            int lugar = -1;
            for (int i = 0; i < this._cantMaximaColores; i++)
            {
                if (this._colores.GetValue(i) == null)
                {
                    lugar = i;
                    break;
                }
            }
            return lugar;
        }


    }
}
