﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Cosa objeto = new Cosa(1,"Hola");
            Cosa obj2 = new Cosa(12, "objeto2",new DateTime(2000,10,10));
            Cosa obj3 = new Cosa();


            objeto.color = ConsoleColor.Red;
            obj3.color = ConsoleColor.Red;


            //muestro los valores iniciales
            Console.WriteLine(objeto.Mostrar());
            //Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(obj2.Mostrar());
            //Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine(obj3.Mostrar());


            //cargo los atributos
            objeto.EstablecerValor("lalalala");
            objeto.EstablecerValor(ConsoleColor.Red);
            objeto.EstablecerValor(17);
            objeto.EstablecerValor(new DateTime(1994,12,17));
            //objeto.EstablecerValor(DateTime.Now);
            obj2.EstablecerValor("chau");



            //vuelvo a mostrar los valores despues de cargarlos
            Console.WriteLine(obj2.Mostrar());
            Console.WriteLine(objeto.Mostrar());
            Console.ReadLine();
        }
    }
}
