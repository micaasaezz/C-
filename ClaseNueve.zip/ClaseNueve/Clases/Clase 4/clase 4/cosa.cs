﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase_4
{
    public class Cosa
    {
        /// <summary>
        /// un numero
        /// </summary>
        public int entero;
        public ConsoleColor color;
        /// <summary>
        /// una cadena de caracteres por ejemplo: tengo hambre, tengo sueño, tengo mas hambre que sueño aunque estaria para esta en casa calentito tirado en la cama
        /// </summary>
        public string cadena;
        /// <summary>
        /// una fecha
        /// </summary>
        public DateTime fecha;


        /// <summary>
        /// inicializa entero en 0, cadena en vacio y fecha en la fecha actual
        /// </summary>
        public Cosa()
        {
            this.entero = 0;
            this.cadena = "Sin valor";
            this.fecha = DateTime.Now;
            this.color = ConsoleColor.Gray;
        }

        
        /// <summary>
        /// inicializa el entero en el valor que el usuario pida
        /// </summary>
        /// <param name="entero">el numero que sera cargado</param>
        /*
        public Cosa(int entero)
        {
            this.entero = entero;
            this.cadena = "Sin valor";
            this.fecha = DateTime.Now;
        }
        */
        //para poder reutilizar codigo
        public Cosa(int entero):this()//el : this es para elegir un constructor
        {
            this.entero = entero;
        }


        /// <summary>
        /// inicializa los atributos con los valores entero y cadena que se le pase
        /// </summary>
        /// <param name="entero">El numero que sera cargado</param>
        /// <param name="cadena">La cadena que sera cargada</param>
        /*
        public Cosa(int entero,string cadena)
        {
            this.entero = entero;
            this.cadena = cadena;
            this.fecha = DateTime.Now;
        }
        */
        //llama al constructor que recibe un parametro
        public Cosa(int entero, string cadena):this(entero)    
        {
            this.cadena = cadena;
        }

        /// <summary>
        /// inicializa fecha entero y cadena en los parametros cargados
        /// </summary>
        /// <param name="entero">El entero que sera cargado</param>
        /// <param name="cadena">La cadena que sera cargada</param>
        /// <param name="fecha">La fecha que sera cargada</param>
        public Cosa(int entero, string cadena, DateTime fecha):this(entero,cadena)
        {
            this.fecha = fecha;
        }


        /// <summary>
        /// Carga el atributo entero de la clase
        /// </summary>
        /// <param name="entero">El dato que sera cargado</param>
        public void EstablecerValor(int entero)
        {
            this.entero = entero;
        }


        /// <summary>
        /// Carga el atributo cadena de la clase
        /// </summary>
        /// <param name="cadena">El dato que sera cargado</param>
        public void EstablecerValor(string cadena)
        {
            this.cadena=cadena;
        }

        /// <summary>
        /// Carga el atributo fecha de la clase
        /// </summary>
        /// <param name="fecha">El dato que sera cargado</param>
        public void EstablecerValor(DateTime fecha)
        {
            this.fecha = fecha;
        }

        /// <summary>
        /// carga un color 
        /// </summary>
        /// <param name="color">color que sera cargado</param>
        public void EstablecerValor(ConsoleColor color)
        {
            this.color = color;
        }

    
        /// <summary>
        /// muestra los valores de los atributos entero cadena y fecha
        /// </summary>
        /// <returns></returns>
        public string Mostrar()
        { 
            string valor;
            Console.ForegroundColor = this.color;
            valor=("Entero: "+this.entero+"\nCadena: "+this.cadena+"\nFecha: "+this.fecha+"\nColor: "+this.color+"\n");
          
            return valor;
        }
    }
    
}
