﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clase06.entidades;

namespace Clase_07
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
