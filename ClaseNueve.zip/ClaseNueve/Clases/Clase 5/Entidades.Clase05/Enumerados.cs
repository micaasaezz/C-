﻿public enum ETipoTinta
{
    Comun,China,ConBrillito
}