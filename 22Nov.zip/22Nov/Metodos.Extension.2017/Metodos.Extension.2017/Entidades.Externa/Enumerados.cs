﻿namespace Entidades.Externa
{
    public enum ESexo
    {
        Femenino,
        Masculino,
        Indefinido
    }
}