﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Externa;

namespace ClassLibrary
{
    public class Derivada : PersonaExterna
    {
        public string ObtenerInfo()
        {
            StringBuilder ret = new StringBuilder();
            ret.Append(base._nombre + " " + base._apellido + " - " + base._edad.ToString() + "- " + base._sexo);
            return ret.ToString();
        }

        public Derivada(string nombre, string apellido, int edad, Entidades.Externa.ESexo sexo)
            : base(nombre, apellido, edad, sexo)
        {
 
        }



    }
}
