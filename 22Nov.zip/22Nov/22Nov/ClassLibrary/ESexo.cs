﻿public enum ESexo
{
    Masculino, Femenino, Indefinido
}