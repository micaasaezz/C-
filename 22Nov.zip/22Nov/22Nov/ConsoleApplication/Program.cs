﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;
using Entidades.Externa;
using Entidades.Externa.Sellada;

namespace ConsoleApplication
{
    static class Program
    {
        static void Main(string[] args)
        {
            //Persona persona1 = new Persona("Juan", "Perez", "23", ESexo.Masculino);

            //#1 propiedades o getters
            //Console.Write(persona1.Nombre + " " + persona1.Apellido);
            //Console.WriteLine(" - " + persona1.Edad + " - " + persona1.Sexo.ToString());

            //metodo que muestre la informacion del objeto
            //Console.WriteLine(persona1.ObtenerInfo());

            //PersonaExterna persona2 = new PersonaExterna("Julian", "Perez", 32, Entidades.Externa.ESexo.Masculino);
            
            //#2 herencia
            //Derivada persona2 = new Derivada("Jose", "Perez", 32, Entidades.Externa.ESexo.Masculino);
            //Console.WriteLine(persona2.ObtenerInfo());

            //clase sellada
            PersonaExternaSellada persona3 = new PersonaExternaSellada("Juana", "Perez", 13, Entidades.Externa.Sellada.ESexo.Femenino);
            //Console.Write(persona3.Nombre + " " + persona3.Apellido + " - " + persona3.Edad + " - " + persona3.Sexo);

            //con metodo desde el main
            //Console.WriteLine(Program.ObtenerInfoMain(persona3));
            
            //con metodo extension
            //Console.WriteLine(persona3.ObtenerInfoExt());
            
            //extension con bool
            Console.WriteLine(persona3.ObtenerInfoExt(false));

            //String v = "string";
            //Console.WriteLine("Tiene {0} caracteres.", v.CantidadCaracteres());



            Console.Read();
        }


        public static string ObtenerInfoMain(PersonaExternaSellada p)
        {
            return p.Nombre + " " + p.Apellido + " - " + p.Edad + " - " + p.Sexo; 
        }

        //metodo de extension, va a simular ser un metodo
        //de instancia de la clase sellada
        //deben ser static y estar en una clase static
        public static string ObtenerInfoExt(this PersonaExternaSellada p)
        {
            return p.Nombre + " " + p.Apellido + " - " + p.Edad + " - " + p.Sexo;
        }
        public static string ObtenerInfoExt(this PersonaExternaSellada p, bool b)
        {
            string ret = (p.Nombre + " " + p.Apellido + " - " + p.Edad + " - " + p.Sexo);
            if (b)
            {
                ret.ToUpper();
            }
            else
            {
                ret.ToLower();
            }
            return ret;
        }

        //metodo de extension para la clase string
        public static int CantidadCaracteres(this String s)
        {
            return s.Length;
        }

    }

}
