﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Cocina
    {
        private int _codigo;
        private bool _esIndustrial;
        private double _precio;

        public int Codigo { get { return this._codigo; } }
        public bool EsIndustrial { get { return this._esIndustrial; } }
        public double Precio { get { return this._precio; } }

        public Cocina()
        { }

        public Cocina(int codigo, double precio, bool industrial)
        {
            this._precio = precio;
            this._esIndustrial = industrial;
            this._codigo = codigo;
        }

        public static bool operator ==(Cocina a, Cocina b)
        {
            return a.Codigo == b.Codigo;
        }
        public static bool operator !=(Cocina a, Cocina b)
        {
            return !(a == b);
        }


        public override string ToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.Append("Codigo: ");
            ret.Append(this.Codigo.ToString());
            ret.Append("  -  Precio: ");
            ret.Append(this.Precio.ToString());
            ret.Append("  -  Es industrial: ");
            ret.Append(this.EsIndustrial.ToString());

            return ret.ToString();
        }

        public override bool Equals(object obj)
        {
            return obj is Cocina && (Cocina) obj == this;
        }

    }
}
