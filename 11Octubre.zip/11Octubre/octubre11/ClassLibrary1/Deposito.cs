﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Deposito<T> where T : new()
    {
        private int _capacidadMaxima;
        private List<T> _lista;

        public Deposito()
        {
            this._lista = new List<T>();
        }

        public Deposito(int capacidad) :this()
        {
            try
            {
                if (capacidad > 50)
                {
                    this._capacidadMaxima = 50;
                    throw new Exception("Se supero la capacidad de la lista");
                }
                else if(capacidad < 1)
                {
                    this._capacidadMaxima = 1;
                    throw new Exception("La capacidad debe ser mayor a 1");
                }

                this._capacidadMaxima = capacidad;
                
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            
            
        }

        public List<T> Lista { get { return this._lista; } }
        public int Capacidad { get { return this._capacidadMaxima - this.Lista.Count; } }

        private int GetIndice(T a)
        {
            int retorno = -1;
            for (int i = 0; i < this._lista.Count; i++)
            {
                if (a.Equals(this._lista[i]))
                {
                    retorno = i;
                    break;
                }
            }
            return retorno;
        }

        public static bool operator +(Deposito<T> d, T a)
        {
            bool pudo = false;
            
                if (d.Capacidad > 0)
                {
                    d._lista.Add(a);
                    pudo = true;
                }
                else
                {
                    throw new DepositoLlenoException();
                }

            
            return pudo;
        }

        public static bool operator -(Deposito<T> d, T a)
        {
            bool pudo = false;
            if (d.GetIndice(a) != -1)
            {
                d._lista.RemoveAt(d.GetIndice(a));
                pudo = true;
            }
            return pudo;
        }

        public bool Agregar(T a)
        {
            return this + a;
        }
        public bool Remover(T a)
        {
            return this - a;
        }


        public override string ToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.Append("Capacidad Maxima: ");
            ret.AppendLine(this._capacidadMaxima.ToString());
            ret.Append("Listado de ");
            ret.AppendLine(typeof(T).Name);
            foreach (T i in this._lista)
            {
                ret.AppendLine(i.ToString());
            }
            return ret.ToString();
        }
    }
}
