﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Deposito<T> where T : new()
    {
        private int _capacidadMaxima;
        private List<T> _lista;

        public Deposito(int capacidad)
        {
            this._capacidadMaxima = capacidad;
            this._lista = new List<T>();
        }

        public static bool operator +(Deposito<T> d, T a)
        {
            bool pudo = false;
            if (d._capacidadMaxima > d._lista.Count)
            {
                d._lista.Add(a);
                pudo = true;
            }
            return pudo;
        }

        private int GetIndice(T a)
        {
            int retorno = -1;
            for (int i = 0; i < this._lista.Count; i++)
            {
                if (a.Equals(this._lista[i]))
                {
                    retorno = i;
                    break;
                }
            }
            return retorno;
        }


        public static bool operator -(Deposito<T> d, T a)
        {
            bool pudo = false;
            if (d.GetIndice(a) != -1)
            {
                d._lista.RemoveAt(d.GetIndice(a));
                pudo = true;
            }
            return pudo;
        }

        public bool Agregar(T a)
        {
            return this + a;
        }
        public bool Remover(T a)
        {
            return this - a;
        }


        public override string ToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.Append("Capacidad Maxima: ");
            ret.AppendLine(this._capacidadMaxima.ToString());
            ret.Append("Listado de ");
            ret.AppendLine(typeof(T).Name);
            foreach (T i in this._lista)
            {
                ret.AppendLine(i.ToString());
            }
            return ret.ToString();
        }
    }
}
