﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class DepositoDeCocinas
    {
        private int _capacidadMaxima;
        private List<Cocina> _lista;

        public DepositoDeCocinas(int capacidad)
        {
            this._capacidadMaxima = capacidad;
            this._lista = new List<Cocina>();
        }

        public static bool operator +(DepositoDeCocinas d, Cocina c)
        {
            bool pudo = false;
            if (d._capacidadMaxima > d._lista.Count)
            {
                d._lista.Add(c);
                pudo = true;
            }
            return pudo;
        }

        private int GetIndice(Cocina c)
        {
            int retorno = -1;
            for (int i = 0; i < this._lista.Count; i++)
            {
                if (this._lista[i] == c)
                {
                    retorno = i;
                    break;
                }
            }
            return retorno;
        }


        public static bool operator -(DepositoDeCocinas d, Cocina c)
        {
            bool pudo = false;
            if (d.GetIndice(c) != -1)
            {
                d._lista.RemoveAt(d.GetIndice(c));
                pudo = true;
            }
            return pudo;
        }

        public bool Agregar(Cocina c)
        {
            return this + c;
        }
        public bool Remover(Cocina c)
        {
            return this - c;
        }


        public override string ToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.Append("Capacidad Maxima: ");
            ret.AppendLine(this._capacidadMaxima.ToString());
            ret.AppendLine("Listado de cocinas ");
            foreach (Cocina i in this._lista)
            {
                ret.AppendLine(i.ToString());
            }
            return ret.ToString();
        }

    }
}
