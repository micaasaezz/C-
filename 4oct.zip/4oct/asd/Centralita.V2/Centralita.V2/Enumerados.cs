﻿public enum Franja
{
    Franja_1,
    Franja_2,
    Franja_3
}

public enum TipoLlamada
{
    Local,
    Provincial,
    Todas
}