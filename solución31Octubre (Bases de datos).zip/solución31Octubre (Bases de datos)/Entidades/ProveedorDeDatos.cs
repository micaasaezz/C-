﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Entidades
{
    public class ProveedorDeDatos
    {
        private SqlConnection _conexion;
        private SqlCommand _comando;

        public ProveedorDeDatos() 
        {
            this._conexion = new SqlConnection(Properties.Settings.Default.Conexion);
            this._comando = new SqlCommand();
        }

        #region Métodos en memoria
        public static List<Persona> obtenerPersonasHC()
        {
            List<Persona> listaPersonas = new List<Persona>();

            Persona personita1 = new Persona(38999220, "Ezequiel", "Mahafud", 22);
            Persona personita2 = new Persona(39590490, "Santiago", "Moran", 21);
            Persona personita3 = new Persona(40000000, "Marcos", "Rey", 19);
            Persona personita4 = new Persona(41000000, "Micaela", "Saez", 18);

            listaPersonas.Add(personita1);
            listaPersonas.Add(personita2);
            listaPersonas.Add(personita3);
            listaPersonas.Add(personita4);

            return listaPersonas;
        }

        public static Persona obtenerPersonaPorID(int id)
        {
            List<Persona> listaPersonas = ProveedorDeDatos.obtenerPersonasHC();

            for (int i = 0; i < listaPersonas.Count; i++)
            {
                if (listaPersonas[i]._id == id)
                    return listaPersonas[i];
            }

            return null;
        }

        public static bool agregarPersona(Persona persona)
        {
            List<Persona> listaPersonas = ProveedorDeDatos.obtenerPersonasHC();

            if (persona != null)
            {
                listaPersonas.Add(persona);
                return true;
            }

            return false;
        }

        public static bool modificarPersona(Persona persona)
        {
            List<Persona> listaPersonas = ProveedorDeDatos.obtenerPersonasHC();
            Persona auxPersona = obtenerPersonaPorID(persona._id);

            if (auxPersona != null)
            {
                ProveedorDeDatos.eliminarPersona(auxPersona);

                auxPersona._nombre = "Josias";
                auxPersona._apellido = "Rivola";
                auxPersona._edad = 22;

                ProveedorDeDatos.agregarPersona(auxPersona);

                return true;
            }

            return false;
        }

        public static bool eliminarPersona(Persona persona)
        {
            List<Persona> listaPersonas = ProveedorDeDatos.obtenerPersonasHC();
            Persona auxPersona = obtenerPersonaPorID(persona._id);

            if (auxPersona != null)
            {
                listaPersonas.Remove(auxPersona);
                return true;
            }

            return false;
        }
        #endregion

        public List<Persona> obtenerPersonasBD() 
        {
            List<Persona> listaPersonas = new List<Persona>();
            
            this._comando.Connection = this._conexion;
            this._comando.CommandType = CommandType.Text;
            this._comando.CommandText = "SELECT * FROM personas";

            this._conexion.Open();

            SqlDataReader data = this._comando.ExecuteReader();

            while (data.Read()) 
            {
                listaPersonas.Add(new Persona((int)data["id"], (string)data["nombre"], (string)data["apellido"], (int)data["edad"]));
            }

            data.Close();
            this._conexion.Close();

            return listaPersonas;
        }

        public Persona obtenerPersonaPorIDBD(int id)
        {
            List<Persona> listaPersonas = new List<Persona>();

            this._comando.Connection = this._conexion;
            this._comando.CommandType = CommandType.Text;
            this._comando.CommandText = "SELECT * FROM personas WHERE id = " + id;

            this._conexion.Open();

            SqlDataReader data = this._comando.ExecuteReader();

            if (data.HasRows) 
            {
                data.Read();
                Persona personita = new Persona((int)data["id"], (string)data["nombre"], (string)data["apellido"], (int)data["edad"]);

                data.Close();
                this._conexion.Close();

                return personita;
            }

            data.Close();
            this._conexion.Close();

            return null;
        }

        public bool agregarPersonaBD(Persona persona)
        {
            StringBuilder consulta = new StringBuilder();
            int retorno;

            consulta.AppendFormat("INSERT INTO personas (nombre, apellido, edad) VALUES ('{0}', '{1}', '{2}')", persona._nombre, persona._apellido, persona._edad);

            this._comando.Connection = this._conexion;
            this._comando.CommandType = CommandType.Text;
            this._comando.CommandText = consulta.ToString();

            this._conexion.Open();

            retorno = this._comando.ExecuteNonQuery();

            this._conexion.Close();

            return retorno >= 1 ? true : false;
        }

        public bool eliminarPersonaBD(Persona persona)
        {
            int retorno;

            this._comando.Connection = this._conexion;
            this._comando.CommandType = CommandType.Text;
            this._comando.CommandText = "DELETE FROM personas WHERE id = " + persona._id;

            this._conexion.Open();

            retorno = this._comando.ExecuteNonQuery();

            this._conexion.Close();

            return retorno >= 1 ? true : false;
        }

        public bool modificarPersonaBD(Persona persona)
        {
            StringBuilder consulta = new StringBuilder();
            int retorno;

            consulta.AppendFormat("UPDATE personas SET nombre = '{0}', apellido = '{1}', edad = {2} WHERE id = {3}", persona._nombre, persona._apellido, persona._edad, persona._id);

            this._comando.Connection = this._conexion;
            this._comando.CommandType = CommandType.Text;
            this._comando.CommandText = consulta.ToString();

            this._conexion.Open();

            retorno = this._comando.ExecuteNonQuery();

            this._conexion.Close();

            return retorno >= 1 ? true : false;
        }
    }
}
