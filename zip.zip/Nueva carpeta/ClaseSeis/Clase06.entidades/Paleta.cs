﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase06.entidades
{
    public class Paleta
    {
        private Tempera[] _colores;
        private int _cantMaximaColores;


        private Paleta() :this(5)
        {
        }

        private Paleta(int cant) 
        {
            this._cantMaximaColores = cant;                 
            this._colores = new Tempera [this._cantMaximaColores];
        }

        public static implicit operator Paleta (int c)
        {
            return new Paleta(c);
        }
        public static implicit operator string(Paleta p)
        {
            return p.ToString();
        }

        private string Mostrar()
        {
            string ret = ""; 
            foreach(Tempera i in this._colores)
            {
                ret += Tempera.Mostrar(i);
            }
           
            return "Cantidad: " + this._cantMaximaColores + "\nColores:\n"+ ret; 
        }

        public static string Mostrar(Paleta p)
        {
            return p.Mostrar(); 
        }

        public static bool operator ==(Paleta p, Tempera t)
        {
            bool pudo = false;
            foreach(Tempera i in p._colores)
            {
                if (i == t)
                {
                    pudo = true;
                }
            }
            return pudo;
        }
        public static bool operator !=(Paleta p, Tempera t)
        {
            return !(p == t);
        }

        
        //+(paleta, tempera):paleta -> si la tempera NO esta en la paleta
        public static Paleta operator + (Paleta p, Tempera temp)
        {
            if(p!= temp)
            {
                for (int i= 0; i< p._cantMaximaColores; i++)
                {
                    if(p._colores[i] == null)
                    {
                        p._colores[i] = temp;
                        p._cantMaximaColores++;
                        break;
                    }
                }
            }
            return p;
        }

        //-(paleta, tempera):paleta  -> si la tempera esta en la paleta

        public static Paleta operator -(Paleta p, Tempera t)
        {
            if(p == t)
            {
                for (int i = 0; i < p._cantMaximaColores; i++)
                {
                    if (p._colores[i] == t)
                    {
                        p._colores = null;
                        p._cantMaximaColores--;
                        break;
                    }
                }
                
            }
            return p;
        }

        //+(paleta, paleta):paleta
        public static Paleta operator +(Paleta p, Paleta p1)
        {

        }

    }
}
