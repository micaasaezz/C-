﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase8
{
    public class Paleta
    {
        private int _cantMaximaColores;
        List<Tempera> listTemperas;

        private Paleta() : this(5)
        {

        }

        private Paleta(int cantidad)
        {
            this._cantMaximaColores = cantidad;
            this.listTemperas = new List<Tempera>();
        }


        /// <summary>
        /// Parecido al constructor porque le da la cantidad de espacios a la paleta
        /// </summary>
        /// <param name="cantidad">Int que determina la cantidad maxima de colores que posee la paleta</param>
        /// <returns>Objeto tipo Paleta</returns>
        public static implicit operator Paleta(int cantidad)
        {
            return new Paleta(cantidad);
        }

        /// <summary>
        /// muestra los atributos de el objeto paleta y cada uno de los objetos tipo Temperas contenidos
        /// </summary>
        /// <returns>string datos </returns>
        private string Mostrar()
        {
            string mensaje = "Paleta: \nCant max colores: " + this._cantMaximaColores + " \n";

            for (int i = 0; i < this.listTemperas.Count; i++)
            {
                mensaje += Tempera.Mostrar(this.listTemperas[i]);
            }

            return mensaje + " \n";
        }
        /// <summary>
        /// Muestra los atributos del objeto de tipo Paleta
        /// </summary>
        /// <param name="paleta">Objeto que sera mostrado</param>
        /// <returns></returns>
        public static string Mostrar(Paleta paleta)
        {
            return paleta.Mostrar();
        }

        /// <summary>
        /// Verifica si el objeto de tipo Tempera esta contenido en el objeto tipo Paleta
        /// </summary>
        /// <param name="paleta">Paleta que sera verificada</param>
        /// <param name="tempera">Tempera que sera verificada</param>
        /// <returns>True en caso de contener el objeto, False en caso contrario</returns>
        public static bool operator ==(Paleta paleta, Tempera tempera)
        {
            bool igual = false;
            for (int i = 0; i < paleta.listTemperas.Count; i++)
            {
                if (paleta.listTemperas[i] == tempera)
                {
                    igual = true;
                    break;
                }
            }
            return igual;
        }


        /// <summary>
        /// Verifica si el objeto de tipo Tempera no esta contenido en el objeto tipo Paleta
        /// </summary>
        /// <param name="paleta">Paleta que sera verificada</param>
        /// <param name="tempera">Tempera que sera verificada</param>
        /// <returns>True en caso de no contener el objeto, False en caso contrario</returns>
        public static bool operator !=(Paleta paleta, Tempera tempera)
        {
            return !(paleta == tempera);
        }

        /// <summary>
        /// Suma una Tempera a una Paleta, en caso de que ya este contenida suma la cantidad
        /// </summary>
        /// <param name="paleta">Paleta a la que se agregara una tempera</param>
        /// <param name="tempera">Tempera que sera agregada</param>
        /// <returns>Paleta con la tempera agregada</returns>
        public static Paleta operator +(Paleta paleta, Tempera tempera)
        {

            if (paleta != tempera && paleta.listTemperas.Count < paleta._cantMaximaColores)
            {
                paleta.listTemperas.Add(tempera);
            }
            else//el color esta en la paleta o esta llena
            {
                if (paleta == tempera)
                {
                    for (int i = 0; i < paleta.listTemperas.Count; i++)
                    {
                        if (paleta.listTemperas[i] == tempera)
                        {
                            paleta.listTemperas[i] += tempera;
                            break;
                        }
                    }
                }
            }
            return paleta;
        }

        /// <summary>
        /// quita una Tempera de la Paleta
        /// </summary>
        /// <param name="paleta">Paleta que contiene la tempera</param>
        /// <param name="tempera">Tempera que sera quitada</param>
        /// <returns>Paleta modificada</returns>
        public static Paleta operator -(Paleta paleta, Tempera tempera)
        {
            if (paleta == tempera)
            {
                paleta.listTemperas.Remove(tempera);
            }
            return paleta;
        }


        /*
        /// <summary>
        /// Obtiene el primer lugar libre [null] del array tipo Paleta
        /// </summary>
        /// <returns>[-1]en caso de que no haya lugar libre, o el indice del lugar vacio</returns>
        private int ObtenerIndice()
        {
            int lugar = -1;
            for (int i = 0; i < this._cantMaximaColores; i++)
            {
                if (this._colores.GetValue(i) == null)
                {
                    lugar = i;
                    break;
                }
            }
            return lugar;
        }
        */
        /// <summary>
        /// retorna la lista de temperas
        /// </summary>
        /// <returns></returns>
        //public List<Tempera> GetTempera()
        //{
        //    return this.listTemperas;
        //}



        public List<Tempera> ListTemperas
        {
            get { return this.listTemperas; }
        }


        public Tempera this[int indice]
        {
            get 
            {
                if (indice < 0 || indice >= this.listTemperas.Count)
                {
                    return null;
                }
                else
                {
                    return this.listTemperas[indice];
                }
            }

            set 
            {
                if (indice >= 0 && indice < this.listTemperas.Count)
                {
                    this.listTemperas[indice] = value;
                    //Paleta aux = this + value;
                    //this.listTemperas = aux.listTemperas;  
                }
                else 
                {
                    if (indice == this.listTemperas.Count)
                    {
                        Paleta aux = this + value;
                        this.listTemperas = aux.listTemperas;                        
                    }
                    
                }
            }
        }


        

    }
}
