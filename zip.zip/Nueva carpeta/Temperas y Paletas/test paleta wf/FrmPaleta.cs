﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Clase8;


namespace test_paleta_wf
{
    public partial class FrmPaleta : Form
    {
        private Paleta _paleta;

        public FrmPaleta()
        {
            InitializeComponent();
            this._paleta = 2;
        }
        

        private void button1_Click(object sender, EventArgs e) //+
        {
            //esto era para agregar 1 solo elemento 
            //Tempera tempera = new Tempera(ConsoleColor.Red, "Filgo", 10);
            //this._paleta += tempera;
            //lstColores.Items.Clear();
            //lstColores.Items.Add(Paleta.Mostrar(this._paleta));


            //se crea el formulario que pide la tempera
            FrmTempera frmTempera = new FrmTempera();
            //invoca el formulario y le da el enfoque
            frmTempera.ShowDialog();

            if(frmTempera.DialogResult==DialogResult.OK)
            {
                //agrego la tempera a la paleta
                //this._paleta += frmTempera.getTempera();
                this._paleta[this._paleta.ListTemperas.Count] = frmTempera.getTempera();
                //la muestro por la consola de paleta
                lstColores.Items.Clear();
                foreach (Tempera i in this._paleta.ListTemperas)
                {
                    lstColores.Items.Add(Tempera.Mostrar(i));
                }
                
               
            }
            
        }

        private void button2_Click(object sender, EventArgs e)//borrar
        {
            int index = this.lstColores.SelectedIndex;
            if (index != -1)
            {
                Tempera tempera =this._paleta.ListTemperas[index];
                FrmTempera frmTempera = new FrmTempera(tempera);
                
                frmTempera.ShowDialog();

                if (frmTempera.DialogResult == DialogResult.OK)
                {
                    this._paleta.ListTemperas.RemoveAt(index);
                    lstColores.Items.Clear();
                    foreach (Tempera i in this._paleta.ListTemperas)
                    {
                        
                        lstColores.Items.Add(Tempera.Mostrar(i));
                    }
                }
            }
            
        }

        private void lstColores_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        
       
        
       
    }
}