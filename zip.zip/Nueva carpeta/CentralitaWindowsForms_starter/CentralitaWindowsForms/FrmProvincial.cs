﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CentralitaHerencia;

namespace CentralitaWindowsForms
{
    public partial class FrmProvincial : FrmLlamada
    {
        protected Provincial _llamadaProvincial;

        public Provincial LlamadaProvincial { get { return this._llamadaProvincial; } }

        public FrmProvincial()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnAceptar_Click_1(object sender, EventArgs e)
        {
            this._llamadaProvincial = new Provincial((Franja)comboBox1.Text, this._llamada);

            this.DialogResult = DialogResult.OK;
        }
    }
}
