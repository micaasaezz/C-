﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CentralitaHerencia;

namespace CentralitaWindowsForms
{
    public partial class FrmCentralita : Form
    {
        protected Centralita _central;

        public FrmCentralita()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) //llamada local
        {
            FrmLocal frmLocal = new FrmLocal();
            frmLocal.ShowDialog();

            if (this.DialogResult == System.Windows.Forms.DialogResult.OK)
            {
                this._central.AgregarLlamadas(frmLocal.LlamadaLocal);
                lstVisor.Items.Clear();
                lstVisor.Items.Add(this._central.Mostrar());
            }
        }

        private void button2_Click(object sender, EventArgs e) //llamada provincial
        {
            FrmProvincial frmProvincial = new FrmProvincial();
            frmProvincial.ShowDialog();
            if (this.DialogResult == System.Windows.Forms.DialogResult.OK)
            {
                this._central.AgregarLlamadas(frmProvincial.LlamadaProvincial);
                lstVisor.Items.Clear();
                lstVisor.Items.Add(this._central.Mostrar());
            }
        }

        private void lstVisor_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
