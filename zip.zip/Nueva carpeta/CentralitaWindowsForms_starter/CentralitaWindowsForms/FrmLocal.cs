﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CentralitaHerencia;

namespace CentralitaWindowsForms
{
    public partial class FrmLocal : FrmLlamada
    {
        protected Local _llamadaLocal;

        public Local LlamadaLocal { get { return this._llamadaLocal; } }

        public FrmLocal()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        protected void btnAceptar_Click_1(object sender, EventArgs e)
        {
            this._llamadaLocal = new Local(this._llamada, float.Parse(textBox3.Text));
            this.DialogResult = DialogResult.OK;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

    }
}
