﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Xml.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    [XmlInclude(typeof(Alumno))]
    public class Persona
    {
        protected string _nombre;
        protected string _apellido;

        #region Propiedades
        public string Nombre
        {
            get { return this._nombre; }
            set { this._nombre = value; }
        }
        public string Apellido 
        {
            get { return this._apellido; }
            set { this._apellido = value; }
        }
        #endregion
        #region Constructor
        public Persona()
        {
 
        }

        public Persona(string nombre, string apellido)
        {
            this._nombre = nombre;
            this._apellido = apellido;
        }
        #endregion
        #region Sobrecargas
        public override string ToString()
        {
            return "Nombre: " + this.Nombre + " Apellido: " + this.Apellido;
        }
        #endregion 
    }
}
