﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Alumno : Persona
    {
        public int legajo;

        public Alumno()
        {
 
        }
        public Alumno(string nombre, string apellido, int legajo)
            :base(nombre, apellido)
        {
            this.legajo = legajo;
        }



    }
}
