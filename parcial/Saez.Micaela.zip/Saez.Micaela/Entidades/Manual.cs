﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Manual : Libro
    {
        public ETipo tipo;


        public Manual(string titulo, float precio, string nombre, string apellido, ETipo tipo)
            :base(precio, titulo, nombre, apellido)
        {
            this.tipo = tipo; 
        }

        public string  Mostrar()
        {
            StringBuilder ret = new StringBuilder();
            ret.AppendLine((string)this);
            ret.Append("Tipo: ");
            ret.AppendLine(this.tipo.ToString());

            return ret.ToString();
        }



        public static bool operator ==(Manual a, Manual b)
        {
            return a == b;
        }
        public static bool operator !=(Manual a, Manual b)
        {
            return !(a == b);
        }



        public static implicit operator double(Manual m)
        {
            return (double)m._precio;
        }







    }
}
