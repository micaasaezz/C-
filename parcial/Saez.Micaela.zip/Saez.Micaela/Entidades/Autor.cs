﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Autor
    {
        private string apellido;
        private string nombre;

        public Autor(string nombre, string apellido)
        {
            this.apellido = apellido;
            this.nombre = nombre;
        }

        public static implicit operator string(Autor a)
        {
            return  a.nombre + "  -  " + a.apellido;
        }

        public static bool operator ==(Autor a, Autor b)
        {
            return a.nombre == b.nombre && a.apellido == b.apellido;
        }
        public static bool operator!=(Autor a, Autor b)
        {
            return !(a == b);
        }

    }
}
