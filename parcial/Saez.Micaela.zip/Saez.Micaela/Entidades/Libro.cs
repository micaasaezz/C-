﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Libro
    {
        protected Autor _autor;
        protected int _cantidadDePaginas;
        protected Random _generadorDePaginas;
        protected float _precio;
        protected string _titulo;


        public int CantidadDePaginas { get { return this._cantidadDePaginas; } }


        static Libro()
        {
            
        }
        public Libro(float precio, string titulo, string nombre, string apellido)
            :this(titulo, new Autor(nombre, apellido), precio)
        {

        }
        public Libro(string titulo, Autor autor, float precio)
        {
             this._titulo = titulo;
             this._precio = precio;
             this._autor = autor;
             this._generadorDePaginas = new Random();
             this._generadorDePaginas.Next(10, 580);
        }


        private static string Mostrar(Libro l)
        {
            StringBuilder ret = new StringBuilder();
            ret.Append("TITULO: ");
            ret.AppendLine(l._titulo);
            ret.Append("CANTIDAD DE PAGINAS: ");
            ret.AppendLine(l._cantidadDePaginas.ToString());
            ret.Append("AUTOR: ");
            ret.AppendLine(l._autor);
            ret.Append("PRECIO: ");
            ret.Append(l._precio.ToString());

            return ret.ToString();            
        }


        public static bool operator ==(Libro a, Libro b)
        {
            return (a._titulo == b._titulo && a._autor == b._autor);
        }
        public static bool operator !=(Libro a, Libro b)
        {
            return !(a == b);
        }



        public static explicit operator string (Libro l)
        {
            return Libro.Mostrar(l);
        }









    }
}
