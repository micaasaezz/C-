﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Biblioteca
    {
        private int _capacidad;
        private List<Libro> _libros;

        public double PrecioDeManuales { get { return this.ObtenerPrecio(ELibro.Manual); } }
        public double PrecioDeNovelas { get { return this.ObtenerPrecio(ELibro.Novela); } }
        public double PrecioTotal { get { return this.ObtenerPrecio(ELibro.Ambos); } }



        private Biblioteca()
        {
            this._libros = new List<Libro>();
        }
        private Biblioteca(int capacidad) : this()
        {
            this._capacidad = capacidad;
        }


        private double ObtenerPrecio(ELibro tipoLibro)
        {
            double precioNovela = 0;
            double precioManual = 0;
            
            double precio = 0;

            foreach(Libro i in this._libros)
            {
                if(i is Manual)
                {
                    precioManual = (Manual)i;
                    break;
                }
                else if(i is Novela)
                {
                    precioNovela = (Novela)i;
                    break;
                }
            }

            switch (tipoLibro)
            {
                case ELibro.Manual:
                    precio = precioManual;
                    break;

                case ELibro.Novela:
                    precio = precioNovela;
                    break;
                case ELibro.Ambos:
                    precio = precioManual + precioNovela;
                    break;
            }


            return precio;
        }



        public static string Mostrar(Biblioteca e)
        {
            StringBuilder ret = new StringBuilder();
            ret.Append("Capacidad de la biblioteca: ");
            ret.AppendLine(e._capacidad.ToString());
            ret.Append("Total por Manuales: ");
            ret.AppendLine(e.PrecioDeManuales.ToString());
            ret.Append("Total por Novelas: ");
            ret.AppendLine(e.PrecioDeNovelas.ToString());
            ret.Append("Total total: ");
            ret.AppendLine(e.PrecioTotal.ToString());
            ret.AppendLine("****************************");
            ret.AppendLine("Listado de Libros ");
            ret.AppendLine("****************************");
            foreach (Libro i in e._libros)
            {
                if (i is Manual)
                {
                    ret.AppendLine(((Manual)i).Mostrar());
                    ret.Append("");
                }
                else if (i is Novela)
                {
                    ret.AppendLine(((Novela)i).Mostrar());
                    ret.Append("");
                    
                }

                
            }

            return ret.ToString();
        }



        public static implicit operator Biblioteca(int capacidad)
        {
            return new Biblioteca(capacidad);
        }



        public static bool operator ==(Biblioteca e, Libro l)
        {
            bool esta =  false;

            foreach(Libro i in e._libros)
            {
                if(i==l)
                {
                    esta = true;
                    break;
                }
            }

            return esta;
        }
        public static bool operator !=(Biblioteca e, Libro l)
        {
            return !(e==l);
        }


        public static Biblioteca operator +(Biblioteca e, Libro l)
        {
            if (e == l)
            {
                Console.WriteLine("El libro ya está en la bibioteca!!!");
            } 
            else 
            {
                if (e._capacidad > e._libros.Count)
                {
                    e._libros.Add(l);
                }
                else
                {
                    Console.WriteLine("No hay más lugar en la biblioteca!!!");
                }
            }


            return e;

        }










    }
}
