﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    //Delegado
    //comparte el namespace pero no la clase
    //modif de acceso  palabra reservada delegate  firma del metodo que va a delegar
    //firma: retorno Nombre([parametros])
    public delegate void DelEmpl(); //definicion del delegado
    

    public delegate void DelEmplConEmpleado(Empleado e);


    public delegate void DelEmplConEmpleadoYSueldo(Empleado e, double sueldo);


    public delegate void DelEmpleadoSueldo2(object o, EmpleadoEventArgs e);




    public class EmpleadoEventArgs : EventArgs
    {
        public double sueldo;
    }




    public class Empleado
    {
        private string _nombre;
        private string _apellido;
        private double _sueldo;

        public string Nombre 
        {
            get { return this._nombre; }
            set { this._nombre = value; }
        }
        public string Apellido 
        {
            get { return this._apellido; }
            set { this._apellido = value; }
        }
        public double Sueldo 
        {
            get { return this._sueldo; }
            set
            {
                if (value > 9500) 
                {
                   // this.LimiteSueldo();
                    //this.LimiteSueldoEmpleado(this);
                    //this.LimiteSueldoEmpleadoySueldo(this, value);

                    EmpleadoEventArgs e = new EmpleadoEventArgs();
                    e.sueldo = value;
                    this.LimiteEmpleadoSueldo2((object)this, e);

                }
                else if (value > 0)
                {
                    this._sueldo = value;
                }
                else
                {
                    throw new Exception("Sueldo invalido"); 
                }                
            }
        }


        public override string ToString()
        {
            return this.Nombre + " " + this.Apellido + " " + this.Sueldo;
        }

        //Evento para el delegado
        //modif de acc   event   nombre del delegado   nombre del evento
        public event DelEmpl LimiteSueldo;

        public event DelEmplConEmpleado LimiteSueldoEmpleado;

        public event DelEmplConEmpleadoYSueldo LimiteSueldoEmpleadoySueldo;

        public event DelEmpleadoSueldo2 LimiteEmpleadoSueldo2;
    }
}
