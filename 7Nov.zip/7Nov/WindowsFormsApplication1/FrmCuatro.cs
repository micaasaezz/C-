﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class FrmCuatro : Form
    {
        public FrmCuatro()
        {
            InitializeComponent();
            
            this.button1.Click += new EventHandler(this.ManejadorGenerico);
           
        }

        private void FrmCuatro_Load(object sender, EventArgs e)
        {
            this.button1.Click += new EventHandler(ManejadorGenerico);
            this.label1.Text = "Manejador en boton 1";
        }

        void ManejadorGenerico(object obj, EventArgs eventos)
        {
            if (obj == this.button1)
	        {
               this.button2.Click += new EventHandler(this.ManejadorGenerico);
               this.button1.Click -= new EventHandler(this.ManejadorGenerico);
               
               this.label1.Text = "Manejador en el boton 2";
            }
            else if (obj == this.button2)
            {
                
                this.button2.Click -= new EventHandler(this.ManejadorGenerico); 
                this.button3.Click += new EventHandler(this.ManejadorGenerico);
                this.label1.Text = "Manejador en el boton 3";
            }
            else if (obj == this.button3)
            {
                
                this.button4.Click += new EventHandler(this.ManejadorGenerico);
                this.button3.Click -= new EventHandler(this.ManejadorGenerico);
                this.label1.Text = "Manejador en el boton 4";
            }
            else if (obj == this.button4)
            {
                
                this.button1.Click += new EventHandler(this.ManejadorGenerico);
                this.button4.Click -= new EventHandler(this.ManejadorGenerico);
                this.label1.Text = "Manejador en el boton 1";
            }

            MessageBox.Show("Soy " + ((Button)obj).Name);
        }

    }
}
