﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary1;

namespace WindowsFormsApplication1
{
    public partial class FrmAgregar : Form
    {
        void ManejadorEmpleadoSueldo(Empleado e, double sueldo)
        {
            MessageBox.Show("Empleado:" + e.ToString() + "  Sueldo que se quiso poner: " +sueldo.ToString());
        }


        public FrmAgregar()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Empleado empl = new Empleado();

            empl.LimiteSueldoEmpleadoySueldo += new DelEmplConEmpleadoYSueldo(ManejadorEmpleadoSueldo);

            empl.Nombre = this.textBoxNombre.Text;
            empl.Apellido = this.textBoxApellido.Text;
            empl.Sueldo = double.Parse(this.textBoxSueldo.Text);


            this.DialogResult = DialogResult.OK;
            
        }

        



    }
}
