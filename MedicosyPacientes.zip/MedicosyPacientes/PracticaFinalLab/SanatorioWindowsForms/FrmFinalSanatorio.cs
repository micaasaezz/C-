﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
using System.Threading;

namespace SanatorioWindowsForms
{
    public partial class FrmFinalSanatorio : Form
    {
        public FrmFinalSanatorio()
        {
            InitializeComponent();
            this._medicoEspecialista = new MEspecialista("Jorge", "Iglesias", MEspecialista.Especialidad.Traumatologo);
            this._medicoGeneral = new MGeneral("Luis", "Salinas");
            this._pacientesEnEspera = new Queue<Paciente>();
            this._mocker = new Thread(this.MockPacientes);
        }

        private MEspecialista _medicoEspecialista;
        private MGeneral _medicoGeneral;
        private Thread _mocker;
        private Queue<Paciente> _pacientesEnEspera;

        private void AtenderPacientes(IMedico iMedico)
        {
            if (this._pacientesEnEspera.Count > 0) 
            {
                this.FinAtencion(this._pacientesEnEspera.Dequeue(), (Medico)iMedico);
            }
        }

        private void btnEspecialista_Click(object sender, EventArgs e)
        {
            this.AtenderPacientes(this._medicoEspecialista);
        }

        private void btnGeneral_Click(object sender, EventArgs e)
        {
            this.AtenderPacientes(this._medicoGeneral);
        }

        private void FinAtencion(Paciente p, Medico m)
        {
            StringBuilder ret = new StringBuilder();
            ret.AppendFormat("Finalizo la atencion de {0} por {1} !", p.ToString(), m.ToString());
            MessageBox.Show(ret.ToString());
        }

        private void FrmFinalSanatorio_Load(object sender, EventArgs e)
        {
            this._mocker.Start();
        }

        private void FrmFinalSanatorio_FromClosing(object sender, FormClosingEventArgs e)
        {
            if(this._mocker.IsAlive)
            {
                this._mocker.Abort();
            }
        }

        private void MockPacientes()
        {
            //this._pacientesEnEspera.Enqueue();
            Thread.Sleep(5000);
        }

    }
}
