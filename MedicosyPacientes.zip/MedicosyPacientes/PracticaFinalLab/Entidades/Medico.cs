﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Medico : Persona
    {
        private Paciente _pacienteActual;
        protected static Random _tiempoAleatorio;

        public Paciente AtenderA { set { this._pacienteActual = value; } }
        public virtual string EstaAtendiendoA { get { return this._pacienteActual.ToString(); } }

        static Medico()
        {
            Medico._tiempoAleatorio = new Random();
        }
        public Medico(string nombre, string apellido)
            :base(nombre, apellido)
        {
            
        }


        protected abstract void Atender();

        protected void FinalizarAtencion()
        {
            this.AtencionFinalizada = new FinAtencionPaciente(this.Atender);
            this._pacienteActual = null;
        }

        public event FinAtencionPaciente AtencionFinalizada;

    }

    public delegate void FinAtencionPaciente();

}
