﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Entidades
{
    public class MEspecialista : Medico , IMedico
    {
        public enum Especialidad
        {
            Traumatologo, Odontologo
        }

        private Especialidad _especialidad;

        public MEspecialista(string nombre, string apellido, Especialidad e)
            :base(nombre,apellido)
        {
            this._especialidad = e;
        }


        protected override void Atender()
        {
            Random r = new Random();
            Thread.Sleep(r.Next(5000, 10000));
        }

        public void IniciarAtencion(Paciente p)
        {
            Thread t = new Thread(this.Atender);
            t.Start();
        }

    }
}
