﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Paciente : Persona
    {
        private int _turno;
        private static int _ultTurnoDado;

        public int Turno { get { return this._turno; } }

        static Paciente()
        {
            Paciente._ultTurnoDado = 0;
        }
        public Paciente(string nombre, string apellido)
            :base(nombre, apellido)
        {
            Paciente._ultTurnoDado++;
            this._turno = Paciente._ultTurnoDado;
        }
        public Paciente(string nombre, string apellido, int turno)
            :this(nombre, apellido)
        {
            Paciente._ultTurnoDado = turno;
            this._turno = turno;
        }


        public override string ToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.AppendFormat("Turno N°{0}: {2}, {1}", this.Turno, this._apellido, this._nombre);
            return ret.ToString();
        }

    }
}
