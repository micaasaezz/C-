﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;
using SanatorioWindowsForms;

namespace TestUnitario
{
    [TestClass]
    public class ConstructoresPaciente
    {
        [TestMethod]
        public void TestConstructores()
        {
            Assert.AreEqual((new Paciente("Nombre", "Apellido")).Turno, 1);

            Assert.AreEqual((new Paciente("Nombre", "Apellido", 5)).Turno, 5);
            
            Assert.AreEqual((new Paciente("Nombre", "Apellido")).Turno, 6);

        }

    }
}
