﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary1;

namespace WindowsFormsApplication1
{

    public partial class FrmCalculadora : Form
    {

        private string num1;
        private string num2;
        private string operacion;

      
        public FrmCalculadora()
        {
            InitializeComponent();
            
        }

        private void ManejadorGenerico(object obj, EventArgs evento)
        {
            if(obj == this.buttonLimpiar)
            {
               this.textDisplayer.Clear();
            }
            else if(obj == this.buttonIgual)
            {
               this.panel1.Click -= new EventHandler(this.ManejadorGenerico);
               
               DelegadoOperacion d = new DelegadoOperacion(Calculadora.Sumar);

               this.textDisplayer.Text = (d.Invoke(double.Parse(num1), double.Parse(num2))).ToString();
               


            }    
            else if (obj == this.buttonSuma || obj == this.buttonResta || obj == this.buttonMultiplic || obj == this.buttonDividir)
            {
               this.operacion = ((Button)obj).Text;
               this.panel1.Click += new EventHandler(this.ManejadorGenerico);
               this.num1 = this.textDisplayer.Text;
               this.textDisplayer.Text += ((Button)obj).Text;
            } 
            else
            {
               this.textDisplayer.Text += ((Panel)obj).Text;
                 
               this.buttonSuma.Click += new EventHandler(this.ManejadorGenerico);
               this.buttonDividir.Click += new EventHandler(this.ManejadorGenerico);
               this.buttonMultiplic.Click += new EventHandler(this.ManejadorGenerico);
               this.buttonResta.Click += new EventHandler(this.ManejadorGenerico);
                
            }
        
 
        }


        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button0_Click(object sender, EventArgs e)
        {

        }

        private void FrmCalculadora_Load(object sender, EventArgs e)
        {
            foreach (Control item in this.Controls)
            {
                if (item is Panel)
                {
                    foreach (Control i in this.panel1.Controls)
                    {
                        i.Click += new EventHandler(this.ManejadorGenerico);
                    }
                    
                }

            }

        }
    }
}
