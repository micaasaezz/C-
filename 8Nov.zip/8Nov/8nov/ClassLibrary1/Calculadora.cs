﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public delegate double DelegadoOperacion(double a, double b);

    public class ResultadoEventArgs : EventArgs
    {
        public double resultado;
    }

    public class Calculadora
    {
        
        public static double Sumar(double num1, double num2)
        {
            return num1 + num2;
        }
        public static double Restar(double num1, double num2)
        {
            return num1 - num2;
        }
        public static double Multiplicar(double num1, double num2)
        {
            return num1 * num2;
        }
        public static double Dividir(double num1, double num2)
        {
            return num1 / num2;
        }


        /*public event Delegado Sumar;
        public event Delegado Restar;
        public event Delegado Multiplicar;
        public event Delegado Dividir;*/

    }
}
