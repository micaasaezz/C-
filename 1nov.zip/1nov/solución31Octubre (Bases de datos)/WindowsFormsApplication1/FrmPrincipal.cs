﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class FrmPrincipal : Form
    {
        //private List<Persona> _lista;
        private ProveedorDeDatos _proveedor;
        private DataTable _dataTable;

        public FrmPrincipal()
        {
            InitializeComponent();
            this._proveedor = new ProveedorDeDatos();
            //this._lista = this._proveedor.obtenerPersonasBD();
            this._dataTable = this._proveedor.ObtenerPersonasBD(true);
            
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            FrmABM abm = new FrmABM();
            if (abm.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                //this._proveedor.agregarPersonaBD(abm.PersonaDelForm);
                //this._lista = this._proveedor.obtenerPersonasBD();
                DataRow fila = this._dataTable.NewRow();
                fila["apellido"] = abm.PersonaDelForm._apellido;
                fila["nombre"] = abm.PersonaDelForm._nombre;
                fila["edad"] = abm.PersonaDelForm._edad;

                //this.listBox1.Items.Clear();
                //foreach (Persona item in this._lista)
                //{
                //    this.listBox1.Items.Add(item.ToString());
                //}
                this._dataTable.Rows.Add(fila);


                //list.listbox.datasourse
                this.dataGridView1.DataSource = this._dataTable;
            }

        }

        private void btnModificar_Click(object sender, EventArgs e)
        {

        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            //int indice = this.listBox1.SelectedIndex;
             //DataRow indice = this.dataGridView1.SelectedColumns;
            //if (indice >= 0) 
            //{
                //FrmABM abm = new FrmABM(this._lista[indice]);
                
                //if (abm.ShowDialog() == DialogResult.OK)
                //{
                //    //this._proveedor.eliminarPersonaBD(this._lista[indice]);
                //    //this._lista = this._proveedor.obtenerPersonasBD();
                //    this.listBox1.Items.Clear();
                //    //foreach (Persona item in this._lista)
                //    //{
                //    //    this.listBox1.Items.Add(item.ToString());
                //    //}
                    
                //}

            //}
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            //foreach (Persona item in this._lista)
            //{
            //    this.listBox1.Items.Add(item.ToString());
            //}
            this.dataGridView1.DataSource = this._dataTable;
            this.dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
               
        }

        private void btnBackUp_Click(object sender, EventArgs e)
        {
            this._dataTable.WriteXmlSchema("esquema.xml");
            this._dataTable.WriteXml("datos.xml");
            
        }






    }
}
