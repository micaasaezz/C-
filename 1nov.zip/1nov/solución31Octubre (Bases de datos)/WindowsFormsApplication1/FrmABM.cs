﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace WindowsFormsApplication1
{
    public partial class FrmABM : Form
    {
        private Persona _persona;

        public Persona PersonaDelForm 
        {
            get { return this._persona; }
        }

        public FrmABM()
        {
            InitializeComponent();
        }
        public FrmABM(Persona p) :this()
        {
            //this._persona = p;
            this.txtApellido.Text = p._apellido;
            this.txtNombre.Text = p._nombre;
            this.txtEdad.Text = p._edad.ToString();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            this._persona = new Persona(0, this.txtNombre.Text, this.txtApellido.Text, int.Parse(this.txtEdad.Text));
            
            this.DialogResult = DialogResult.OK;

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }



    }
}
