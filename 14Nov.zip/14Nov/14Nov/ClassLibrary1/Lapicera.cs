﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Lapicera : Utiles
    {
        protected ConsoleColor _color;
        protected string _trazo;

        public string Trazo
        {
            get { return this._trazo; }
            set { this._trazo = value; }
        }
        public ConsoleColor Color
        {
            get { return this._color; }
            set { this._color = value; }
        }

        public override string Marca
        {
            get
            {
                return base._marca;
            }
            set
            {
                base._marca = value;
            }
        }
        public override int Precio
        {
            get
            {
                return base._precio;
            }
            set
            {
                base._precio = value;
            }
        }


        public override string UtilesToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.AppendLine(base.UtilesToString());
            ret.AppendLine("Color: " + this.Color.ToString());
            ret.AppendLine("Trazo: " + this.Trazo);

            return ret.ToString();
        }


    }
}
