﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;


namespace ClassLibrary1
{
    public class BaseDeDatos
    {
        private SqlConnection _conexion;
        private SqlCommand _comando;

        public BaseDeDatos()
        {
            this._conexion = new SqlConnection(Properties.Settings.Default.conexion);
            this._comando = new SqlCommand();
        }


        public void obtenerPersonasBD()
        {
            List<Utiles> lista = new List<Utiles>();

            this._comando.Connection = this._conexion;
            this._comando.CommandType = CommandType.Text;
            this._comando.CommandText = "SELECT * FROM elementos";

            this._conexion.Open();

            SqlDataReader data = this._comando.ExecuteReader();

            while (data.Read())
            {
                Console.WriteLine((data["id"]).ToString()+ (data["marca"]).ToString()+ (data["precio"]).ToString()+
            (data["color"]).ToString()+ (data["trazo"]).ToString()+ (data["soloLapiz"]).ToString());
            }

            data.Close();
            this._conexion.Close();

            
        }

    }
}
