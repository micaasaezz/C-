﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Goma : Utiles
    {
        protected bool _soloLapiz;

        public bool SoloLapiz 
        {
            get { return this._soloLapiz; }
            set { this._soloLapiz = value; }
        }

        public override string Marca
        {
            get
            {
                return base._marca;
            }
            set
            {
                base._marca = value;
            }
        }
        public override int Precio
        {
            get
            {
                return base._precio;
            }
            set
            {
                base._precio = value;
            }
        }

        public override string UtilesToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.AppendLine(base.UtilesToString());
            ret.AppendLine("Solo lapiz: " + this.SoloLapiz.ToString());

            return ret.ToString();
        }


    }
}
