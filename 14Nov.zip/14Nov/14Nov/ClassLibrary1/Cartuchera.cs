﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{

    public class Cartuchera <T> where T:Utiles
    {
        private string _marca;
        private int _capacidad;
        private List<T> _utiles;

        public Cartuchera(int capacidad, string marca)
        {
            this._utiles = new List<T>();
            this._capacidad = capacidad;
            this._marca = marca;
        }


        public void Agregar(T item)
        {
            if (this._utiles.Count < this._capacidad)
            {
                this._utiles.Add(item);

                this.ElementoAgregadoEvent(item, new EventArgs());

            }
            else
            {
                throw new CartucheraLlenaException("Capacidad de la cartuchera superada: " + this._capacidad.ToString());
            }
            
        }

        public override string ToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.AppendLine("Cartuchera:");
            ret.AppendLine("Marca: " + this._marca + " Capacidad: " + this._capacidad.ToString());
            ret.AppendLine("\nÚtiles:");
            foreach (T item in this._utiles)
            {
                ret.AppendLine(item.UtilesToString());
                ret.AppendLine("------");
            }

            return ret.ToString();
        }


        public event Delegado ElementoAgregadoEvent;


    }
}
