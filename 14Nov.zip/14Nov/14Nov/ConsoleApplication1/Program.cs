﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;
using System.IO;
using System.Data;
using System.Data.SqlClient;

namespace ConsoleApplication1
{
    class Program
    {

        public static void Manejador(object objeto, EventArgs evento)
        {
            
            StreamWriter escritor = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + @"\escritura.txt", true);
            try
            {
                DateTime fecha = DateTime.Now;
                escritor.WriteLine(fecha.ToString() + ((Utiles)objeto).UtilesToString());
            }
            catch (Exception)
            {
 
            }

            escritor.Close();
        }


        static void Main(string[] args)
        {

            BaseDeDatos bd = new BaseDeDatos();
            bd.obtenerPersonasBD();

            Console.Read();

            /*
            Cartuchera<Utiles> cartuchera = new Cartuchera<Utiles>(4, "filgo");

            cartuchera.ElementoAgregadoEvent += Program.Manejador;

            Lapicera lapicera1 = new Lapicera();
            lapicera1.Marca = "bic";
            lapicera1.Precio = 12;
            lapicera1.Trazo = "fino";
            lapicera1.Color = ConsoleColor.Blue;

            Lapicera lapicera2 = new Lapicera();
            lapicera2.Marca = "bic";
            lapicera2.Precio = 13;
            lapicera2.Trazo = "grueso";
            lapicera2.Color = ConsoleColor.Red;

            Goma goma1 = new Goma();
            goma1.Marca = "filgo";
            goma1.Precio = 5;
            goma1.SoloLapiz = true;

            Goma goma2 = new Goma();
            goma2.Marca = "filgo";
            goma2.Precio = 6;
            goma2.SoloLapiz = false;

            try
            {
                cartuchera.Agregar(lapicera1);
                cartuchera.Agregar(lapicera2);
                cartuchera.Agregar(goma1);
                cartuchera.Agregar(goma2);
            }
            catch (CartucheraLlenaException e)
            {
                Console.WriteLine(e.Message);             
            }
            

            Console.WriteLine(cartuchera.ToString());
            */
            Console.Read();

        }
    }
}
